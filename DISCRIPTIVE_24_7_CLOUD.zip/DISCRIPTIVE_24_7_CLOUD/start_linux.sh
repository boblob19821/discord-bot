#!/bin/sh
set -eu
cd "$(dirname "$0")"
if [ ! -x .venv/bin/python ]; then
  echo "Set up the environment first: python3 -m venv .venv && .venv/bin/python -m pip install -r requirements.txt"
  exit 1
fi
exec .venv/bin/python bot.py
