# YZVT Marketplace Pro — Setup

This is your existing generator bot **plus** an optional marketplace server builder. It does not delete or reset your existing stock or premium keys.

1. Back up your old `.env` and `data/` folder. Stop your existing bot.
2. Copy the new code into the existing bot folder, retaining your `.env` and `data/`.
3. Start with `start_windows.bat`. New slash commands sync on startup to `TEST_GUILD_ID` if configured.
4. Invite the bot with the `bot` and `applications.commands` scopes. Grant **Manage Channels**, **Manage Roles**, **View Channels**, **Send Messages**, **Embed Links**, and **Read Message History**. Put the bot role above the roles it will manage.
5. In your server run `/market preview`, then `/market build confirm: YES`.
6. Run `/market panels` once to publish shop/generator info cards.
7. Configure your actual ticket panel using existing `/ticket` commands, set prices and product listings manually, and test `/gen free`, `/gen paid`, `/key redeem` and `/vouch`.

**Safety:** `/market build` creates missing channels and roles only. It does not erase anything. Existing categories with the same name are reused without changing their permissions. Carefully review the permissions, especially if an existing category was public. Staff roles are created but not automatically assigned to people. Premium access is not granted automatically. The builder only fills bot settings that were previously empty. `/market panels` can post duplicate messages if repeated.

**Important:** Discord does not permit a bot to create a server on your behalf via ordinary bot permissions; create an empty server yourself first. This script builds it out within that server. It does not process payments.

**Troubleshooting:** If commands do not appear, confirm `TEST_GUILD_ID` is your actual server ID and restart. If role creation fails, ensure the bot has Manage Roles. If private channels are visible publicly, review category overwrites and role permissions (Administrator overrides channel denies).
