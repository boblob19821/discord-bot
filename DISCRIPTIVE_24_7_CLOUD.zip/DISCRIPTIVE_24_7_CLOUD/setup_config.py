"""Safe one-time Windows configuration helper for YZVT Generator Bot.

Never overwrite an existing encryption key: changing it can make stock unreadable.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import re

from cryptography.fernet import Fernet
from dotenv import dotenv_values

ROOT = Path(__file__).resolve().parent
CONFIG = ROOT / ".env"
EXAMPLE = ROOT / ".env.example"
PLACEHOLDER_KEY = "PASTE_GENERATED_FERNET_KEY_HERE"


def setup() -> None:
    if not CONFIG.exists():
        text = EXAMPLE.read_text(encoding="utf-8")
        text = re.sub(
            r"(?m)^STOCK_ENCRYPTION_KEY=.*$",
            "STOCK_ENCRYPTION_KEY=" + Fernet.generate_key().decode(),
            text,
        )
        CONFIG.write_text(text, encoding="utf-8")
        print("Created .env with a new private encryption key.")
        print("Keep this file private and back it up alongside your data folder.")
        return
    text = CONFIG.read_text(encoding="utf-8")
    if re.search(r"(?m)^STOCK_ENCRYPTION_KEY\s*=\s*(?:PASTE_GENERATED_FERNET_KEY_HERE)?\s*$", text):
        text = re.sub(
            r"(?m)^STOCK_ENCRYPTION_KEY\s*=.*$",
            "STOCK_ENCRYPTION_KEY=" + Fernet.generate_key().decode(),
            text,
        )
        CONFIG.write_text(text, encoding="utf-8")
        print("Filled in an unused encryption-key placeholder inside existing .env.")
    else:
        print("Existing .env and encryption key left unchanged.")


def check() -> int:
    if not CONFIG.exists():
        print("ERROR: .env is missing. Run install_windows.bat first.")
        return 1
    data = dotenv_values(CONFIG)
    token = (data.get("DISCORD_TOKEN") or "").strip()
    key = (data.get("STOCK_ENCRYPTION_KEY") or "").strip()
    if not token or token == "PASTE_BOT_TOKEN_HERE":
        print("SETUP REQUIRED: Add your bot token in .env, next to DISCORD_TOKEN=.")
        print("Open settings with: notepad .env")
        return 1
    try:
        Fernet(key.encode())
    except Exception:
        print("ERROR: STOCK_ENCRYPTION_KEY is invalid. Use a valid Fernet key.")
        print("Do not replace an old valid key if you have already stocked the bot.")
        return 1
    server_id = (data.get("TEST_GUILD_ID") or "0").strip()
    if not server_id.isdigit():
        print("ERROR: TEST_GUILD_ID must be a numeric Discord server ID or 0.")
        return 1
    if server_id == "0":
        print("Note: TEST_GUILD_ID=0; global slash commands may take time to appear.")
    print("Configuration looks ready (secrets are not printed).")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    if args.check:
        return check()
    setup()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
