@echo off
setlocal
cd /d "%~dp0"
title YZVT Generator Bot

if not exist ".venv\Scripts\python.exe" (
  echo First-time setup is needed; opening installer...
  call "%~dp0install_windows.bat"
  if errorlevel 1 exit /b 1
)

if not exist ".env" (
  echo Preparing missing .env settings...
  ".venv\Scripts\python.exe" setup_config.py
  if errorlevel 1 goto :fail
)

".venv\Scripts\python.exe" setup_config.py --check
if errorlevel 1 (
  echo.
  echo Edit your config using: notepad .env
  echo Then run this launcher again.
  goto :fail
)

echo.
echo Starting YZVT Generator Bot...
".venv\Scripts\python.exe" bot.py
if errorlevel 1 (
  echo.
  echo Bot stopped with an error. Read the error message above.
  goto :fail
)

echo.
echo Bot has stopped.
pause
exit /b 0

:fail
pause
exit /b 1
