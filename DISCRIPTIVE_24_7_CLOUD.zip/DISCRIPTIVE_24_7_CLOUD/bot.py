"""YZVT Generator Bot — all-slash Discord application.

Only distribute account credentials, codes and inventory you own or are authorised to distribute.
"""
from __future__ import annotations

import asyncio
import logging
import os
from pathlib import Path

import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv
from cryptography.fernet import Fernet

from storage import Database
from core import BotError, now, stamp
from helpers import answer
from cogs.support import TicketPanelView, TicketControlsView


class ReliableCommandTree(app_commands.CommandTree):
    """Acknowledge slash commands before slower I/O to avoid Discord 3s timeouts.

    Slash commands in this bot reply privately, and none open modals. Ticket panel
    buttons use separate component interactions so their modals still work.
    """
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if not interaction.response.is_done():
            await interaction.response.defer(ephemeral=True, thinking=True)
        return True


load_dotenv()
log=logging.getLogger("yzvt")


class YZVT(commands.Bot):
    def __init__(self, token, stock_encryption_key, db_path, test_guild, owner_id):
        intents=discord.Intents.default()
        intents.members=True  # required to welcome members and auto-assign a role
        intents.message_content=True  # transcript access; requires portal toggle
        super().__init__(command_prefix=commands.when_mentioned,intents=intents,
                         allowed_mentions=discord.AllowedMentions(users=False,roles=False,everyone=False),
                         help_command=None,tree_cls=ReliableCommandTree)
        self.token_config=token
        self.db=Database(db_path,stock_encryption_key)
        self.test_guild=test_guild
        self.owner_id_config=owner_id
        self.sync_lock=asyncio.Lock()

    async def setup_hook(self):
        await self.db.start()
        # A crash during ticket creation should not block the member forever.
        await self.db.exec("DELETE FROM tickets WHERE status='pending' AND opened_at<?",(stamp(now())-300,))
        self.add_view(TicketPanelView(self))
        self.add_view(TicketControlsView(self))
        for extension in ('cogs.inventory','cogs.premium','cogs.support','cogs.reviews','cogs.welcome','cogs.admin','cogs.status','cogs.marketplace','cogs.extras'):
            await self.load_extension(extension)
        await self.sync_commands()

    async def sync_commands(self):
        """Reconcile current command definitions with Discord on EVERY startup.

        Sync is a bulk overwrite for the chosen scope: renamed/deleted slash
        commands disappear in the test guild, and new definitions replace them.
        Neither user stock nor the database is reset.
        """
        async with self.sync_lock:
            if self.test_guild:
                guild = discord.Object(id=self.test_guild)
                self.tree.copy_global_to(guild=guild)
                synced = await self.tree.sync(guild=guild)
                log.info('Refreshed %s slash groups/commands for guild %s',len(synced),self.test_guild)
            else:
                synced = await self.tree.sync()
                log.info('Refreshed %s global slash groups/commands',len(synced))
            return len(synced)

    async def apply_presence(self):
        from cogs.status import make_activity, DEFAULT_PRESENCE, parse_presence
        row = await self.db.one("SELECT value FROM bot_settings WHERE name='presence'")
        cfg = parse_presence(row['value'] if row else None)
        await self.change_presence(activity=make_activity(cfg), status=getattr(discord.Status,cfg['state']))
        return cfg

    async def on_ready(self):
        try:
            await self.apply_presence()
        except (discord.HTTPException, ValueError):
            log.exception('Unable to restore saved bot presence')
        log.info('Online as %s (%s), guild count=%s',self.user,self.user.id,len(self.guilds))

    async def close(self):
        try:await self.db.close()
        finally:await super().close()


async def slash_error(interaction:discord.Interaction,error:app_commands.AppCommandError):
    original=getattr(error,'original',error)
    if isinstance(original,BotError):
        msg=f"⚠️ {original}"
    elif isinstance(original,app_commands.CommandOnCooldown):
        msg=f"⏳ Slow down. Try again in **{original.retry_after:.0f}s**."
    elif isinstance(original,app_commands.MissingPermissions):
        msg="⛔ You don't have permission to use this command."
    elif isinstance(original,app_commands.CheckFailure):
        msg="⛔ You don't have permission to use this command."
    elif isinstance(original,discord.Forbidden):
        msg="⚠️ Bot lacks permissions to perform that operation. Check its role position and channel permissions."
    elif isinstance(original,discord.NotFound):
        msg="⚠️ That channel or resource no longer exists."
    else:
        log.error('Command failed: %s',type(original).__name__,exc_info=(type(original),original,original.__traceback__))
        msg="⚠️ Something went wrong. Check the server console for the exception type."
    try:await answer(interaction,msg)
    except discord.HTTPException:pass


def main():
    logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)-8s %(name)s | %(message)s')
    token=os.getenv('DISCORD_TOKEN','').strip()
    key=os.getenv('STOCK_ENCRYPTION_KEY','').strip()
    if not token:
        raise SystemExit('DISCORD_TOKEN missing. Copy .env.example to .env and set your bot token.')
    if not key:
        raise SystemExit('STOCK_ENCRYPTION_KEY missing. Run python create_key.py and put the key in .env.')
    try:Fernet(key.encode())
    except Exception as exc:raise SystemExit('STOCK_ENCRYPTION_KEY must be a valid Fernet key.') from exc
    guild=int(os.getenv('TEST_GUILD_ID','0') or '0')
    owner=int(os.getenv('OWNER_ID','0') or '0')
    bot=YZVT(token,key,os.getenv('DATABASE_PATH','data/yzvt.db'),guild,owner)
    bot.tree.on_error=slash_error
    bot.run(token,log_handler=None)


if __name__=='__main__':main()
