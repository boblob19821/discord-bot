"""High-entropy single-use premium keys with configurable durations."""
import hashlib
import io
from datetime import timedelta
import discord
from discord import app_commands
from discord.ext import commands
from core import BotError, new_key, now, parse_duration, stamp, unix_fmt
from helpers import ensure_deferred, answer, manager_only, audit


@app_commands.guild_only()
class Key(commands.GroupCog, group_name="key",group_description="Redeem and administer premium keys"):
    def __init__(self,bot):self.bot=bot

    @app_commands.command(name="redeem",description="Redeem your single-use premium key privately")
    @app_commands.checks.cooldown(3,60,key=lambda i:(i.guild_id,i.user.id))
    async def redeem(self,interaction:discord.Interaction,code:str):
        expiry=await self.bot.db.redeem(interaction.guild_id,interaction.user.id,code)
        await audit(self.bot,interaction.guild,interaction.user.id,"key.redeem","Premium access activated (key hidden)")
        await answer(interaction,f"✅ **Premium activated!**\nYour access expires: {unix_fmt(expiry)}\nYou can now use `/gen paid`.")

    @app_commands.command(name="status",description="Check your or another member's premium expiry")
    async def status(self,interaction:discord.Interaction,member:discord.Member|None=None):
        target=member or interaction.user
        if target.id != interaction.user.id and not interaction.user.guild_permissions.manage_guild:
            raise BotError("Only server managers can check another user's subscription.")
        row=await self.bot.db.one("SELECT expires_at FROM licenses WHERE guild_id=? AND user_id=?",(interaction.guild_id,target.id))
        cfg=await self.bot.db.setting(interaction.guild_id)
        role_access=bool(cfg['paid_role_id'] and target.get_role(cfg['paid_role_id']))
        expires=row['expires_at'] if row else None
        active=bool(expires and expires>stamp(now()))
        msg=f"💎 **Premium for {target.mention}**\n"
        msg+=f"Key subscription: {'active' if active else 'inactive'}\nExpires: {unix_fmt(expires)}\n"
        msg+=f"Paid role access: {'yes' if role_access else 'no'}"
        await answer(interaction,msg,allowed_mentions=discord.AllowedMentions.none())

    @app_commands.command(name="create",description="Create 1–50 single-use premium keys of a custom duration")
    @manager_only()
    async def create(self,interaction:discord.Interaction,duration:str,quantity:app_commands.Range[int,1,50]=1,redeem_within_days:app_commands.Range[int,0,365]=0):
        parse_duration(duration)
        await ensure_deferred(interaction)
        deadline=stamp(now()+timedelta(days=redeem_within_days)) if redeem_within_days else None
        made=[]
        for _ in range(quantity):
            code=new_key()
            digest=hashlib.sha256(code.encode()).hexdigest()
            await self.bot.db.exec("INSERT INTO access_keys(code_hash,guild_id,duration,created_by,created_at,redeem_before) VALUES(?,?,?,?,?,?)",
                                   (digest,interaction.guild_id,duration,interaction.user.id,stamp(now()),deadline))
            made.append(code)
        payload="\n".join(made)
        await audit(self.bot,interaction.guild,interaction.user.id,"key.create",f"Created {quantity} keys; duration {duration} (codes withheld)")
        embed=discord.Embed(title="🔑 Premium keys created",description=f"**Quantity:** {quantity}\n**Access per key:** `{duration}`\n**Redeem deadline:** {unix_fmt(deadline)}\n**Single-use:** Yes\n\n**Copy the keys now. They cannot be shown again.**",color=discord.Color.gold())
        if len(payload)<1250:
            await answer(interaction,embed=embed,content=f"```\n{payload}\n```")
        else:
            file=discord.File(io.BytesIO(payload.encode()),filename="premium_keys_PRIVATE.txt")
            await answer(interaction,embed=embed,file=file)

    @app_commands.command(name="grant",description="Grant premium directly to a member for a custom duration")
    @manager_only()
    async def grant(self,interaction:discord.Interaction,member:discord.Member,duration:str):
        prior=await self.bot.db.one("SELECT expires_at FROM licenses WHERE guild_id=? AND user_id=?",(interaction.guild_id,member.id))
        start=max(stamp(now()), prior['expires_at'] if prior else 0)
        from core import utc_from_stamp
        expiry=stamp(parse_duration(duration,utc_from_stamp(start)))
        await self.bot.db.exec("INSERT INTO licenses(guild_id,user_id,expires_at) VALUES(?,?,?) "
                               "ON CONFLICT(guild_id,user_id) DO UPDATE SET expires_at=excluded.expires_at",
                               (interaction.guild_id,member.id,expiry))
        await audit(self.bot,interaction.guild,interaction.user.id,"key.grant",f"member {member.id}, duration {duration}")
        await answer(interaction,f"✅ Granted {member.mention} premium until {unix_fmt(expiry)}.",allowed_mentions=discord.AllowedMentions.none())

    @app_commands.command(name="revoke_member",description="Revoke a member's key-based premium subscription")
    @manager_only()
    async def revoke_member(self,interaction:discord.Interaction,member:discord.Member):
        changed=await self.bot.db.exec("DELETE FROM licenses WHERE guild_id=? AND user_id=?",(interaction.guild_id,member.id))
        await audit(self.bot,interaction.guild,interaction.user.id,"key.revoke_member",f"member {member.id}")
        await answer(interaction,f"✅ Subscription {'revoked' if changed else 'was not found'} for {member.mention}. (Paid role, if configured, is separate.)",allowed_mentions=discord.AllowedMentions.none())

    @app_commands.command(name="revoke",description="Revoke an unused premium key by its value")
    @manager_only()
    async def revoke(self,interaction:discord.Interaction,code:str):
        digest=hashlib.sha256(code.strip().upper().encode()).hexdigest()
        row=await self.bot.db.one("SELECT used_by FROM access_keys WHERE code_hash=? AND guild_id=?",(digest,interaction.guild_id))
        if not row:raise BotError("Key not found in this server.")
        if row['used_by'] is not None:raise BotError("This key is already redeemed; use `/key revoke_member` to remove that subscription.")
        await self.bot.db.exec("UPDATE access_keys SET revoked=1 WHERE code_hash=?",(digest,))
        await audit(self.bot,interaction.guild,interaction.user.id,"key.revoke","Unused key revoked (code hidden)")
        await answer(interaction,"✅ Unused key revoked successfully.")

    @app_commands.command(name="overview",description="See issued, redeemed, unused and revoked key counts")
    @manager_only()
    async def overview(self,interaction:discord.Interaction):
        row=await self.bot.db.one("SELECT COUNT(*) AS total, "
                                   "SUM(CASE WHEN used_by IS NOT NULL THEN 1 ELSE 0 END) AS used, "
                                   "SUM(CASE WHEN used_by IS NULL AND revoked=0 THEN 1 ELSE 0 END) AS unused, "
                                   "SUM(CASE WHEN revoked=1 THEN 1 ELSE 0 END) AS revoked "
                                   "FROM access_keys WHERE guild_id=?",(interaction.guild_id,))
        active=await self.bot.db.one("SELECT COUNT(*) AS n FROM licenses WHERE guild_id=? AND expires_at>?",(interaction.guild_id,stamp(now())))
        embed=discord.Embed(title="💎 Premium management",color=discord.Color.gold())
        for title,val in (("Total created",row['total']),("Redeemed",row['used'] or 0),("Unused",row['unused'] or 0),
                          ("Revoked",row['revoked'] or 0),("Active subscriptions",active['n'])):
            embed.add_field(name=title,value=str(val),inline=True)
        await answer(interaction,embed=embed)


async def setup(bot):await bot.add_cog(Key(bot))
