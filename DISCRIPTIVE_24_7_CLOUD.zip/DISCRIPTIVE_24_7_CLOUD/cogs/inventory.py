"""Slash command stock management and free/paid generation."""
import io
import discord
from discord import app_commands
from discord.ext import commands
from core import BotError, validate_category, safe_snippet
from helpers import ensure_deferred, answer, attachment_reply, manager_only, audit


async def complete_categories(interaction: discord.Interaction, current: str):
    if not interaction.guild_id:
        return []
    rows = await interaction.client.db.all(
        "SELECT name,tier FROM categories WHERE guild_id=? AND name LIKE ? ORDER BY name LIMIT 25",
        (interaction.guild_id, f"%{current.strip()}%"))
    return [app_commands.Choice(name=f"{x['name']} [{x['tier']}]", value=x['name']) for x in rows]


@app_commands.guild_only()
@app_commands.default_permissions(manage_guild=True)
class Add(commands.GroupCog, group_name="add", group_description="Add stock and category inventory"):
    def __init__(self, bot): self.bot = bot

    async def _category(self, interaction, name, tier, cooldown_minutes):
        name = validate_category(name)
        if cooldown_minutes < 0 or cooldown_minutes > 10080:
            raise BotError("Cooldown must be 0–10,080 minutes.")
        try:
            await self.bot.db.exec(
                "INSERT INTO categories(guild_id,name,tier,cooldown_sec) VALUES (?,?,?,?)",
                (interaction.guild_id,name,tier,cooldown_minutes*60))
        except __import__('sqlite3').IntegrityError:
            raise BotError("That category already exists. Use `/category edit` instead.")
        await audit(self.bot,interaction.guild,interaction.user.id,"category.create",f"{name} ({tier})")
        await answer(interaction,f"✅ Created **{name}** (`{tier}`) with a **{cooldown_minutes}m** cooldown.")

    @app_commands.command(name="category", description="Create a free or paid inventory category")
    @app_commands.choices(tier=[app_commands.Choice(name="Free",value="free"),app_commands.Choice(name="Paid",value="paid")])
    @manager_only()
    async def category(self, interaction:discord.Interaction, name:str, tier:app_commands.Choice[str], cooldown_minutes:app_commands.Range[int,0,10080]=60):
        await self._category(interaction,name,tier.value,cooldown_minutes)

    @app_commands.command(name="catagory", description="Alias of /add category (alternative spelling)")
    @app_commands.choices(tier=[app_commands.Choice(name="Free",value="free"),app_commands.Choice(name="Paid",value="paid")])
    @manager_only()
    async def catagory(self, interaction:discord.Interaction, name:str, tier:app_commands.Choice[str], cooldown_minutes:app_commands.Range[int,0,10080]=60):
        await self._category(interaction,name,tier.value,cooldown_minutes)

    @app_commands.command(name="stock", description="Bulk add authorised access codes via lines or a UTF-8 .txt file")
    @app_commands.autocomplete(category=complete_categories)
    @manager_only()
    async def stock(self, interaction:discord.Interaction, category:str, lines:str|None=None, attachment:discord.Attachment|None=None):
        if not lines and not attachment:
            raise BotError("Supply stock in `lines` (one entry per line), or attach a UTF-8 `.txt` file.")
        await ensure_deferred(interaction)
        record = await self.bot.db.one("SELECT id FROM categories WHERE guild_id=? AND name=? COLLATE NOCASE",
                                       (interaction.guild_id,category.strip()))
        if not record: raise BotError("Category not found. Use `/add category` first.")
        raw = lines or ""
        if attachment:
            if not attachment.filename.lower().endswith(".txt"):
                raise BotError("Only `.txt` uploads are supported.")
            if attachment.size > 1024*1024:
                raise BotError("Max upload size: 1 MiB.")
            try:
                raw += "\n"+ (await attachment.read()).decode("utf-8-sig")
            except UnicodeDecodeError:
                raise BotError("File must be UTF-8 text.")
        count, duplicates = await self.bot.db.add_stock(interaction.guild_id,record['id'],interaction.user.id,raw.splitlines())
        await audit(self.bot,interaction.guild,interaction.user.id,"stock.import",f"{category}: {count} imported, {duplicates} duplicates")
        await answer(interaction,f"✅ Imported **{count}** entries into **{category}**. Skipped **{duplicates}** duplicates. All entries are encrypted at rest.")


@app_commands.guild_only()
@app_commands.default_permissions(manage_guild=True)
class Category(commands.GroupCog, group_name="category", group_description="Change inventory categories"):
    def __init__(self,bot):self.bot=bot

    @app_commands.command(name="edit",description="Change a category's tier and cooldown")
    @app_commands.choices(tier=[app_commands.Choice(name="Free",value="free"),app_commands.Choice(name="Paid",value="paid")])
    @app_commands.autocomplete(category=complete_categories)
    @manager_only()
    async def edit(self,interaction:discord.Interaction,category:str,tier:app_commands.Choice[str],cooldown_minutes:app_commands.Range[int,0,10080]):
        affected=await self.bot.db.exec("UPDATE categories SET tier=?,cooldown_sec=? WHERE guild_id=? AND name=? COLLATE NOCASE",
                                      (tier.value,cooldown_minutes*60,interaction.guild_id,category))
        if not affected: raise BotError("Category not found.")
        await audit(self.bot,interaction.guild,interaction.user.id,"category.edit",f"{category} {tier.value} {cooldown_minutes}m")
        await answer(interaction,f"✅ Updated **{category}** to **{tier.value}** and cooldown **{cooldown_minutes}m**.")

    @app_commands.command(name="rename",description="Rename a category")
    @app_commands.autocomplete(category=complete_categories)
    @manager_only()
    async def rename(self,interaction:discord.Interaction,category:str,new_name:str):
        new_name=validate_category(new_name)
        try:
            num=await self.bot.db.exec("UPDATE categories SET name=? WHERE guild_id=? AND name=? COLLATE NOCASE",
                                       (new_name,interaction.guild_id,category))
        except __import__('sqlite3').IntegrityError: raise BotError("New category name already exists.")
        if not num: raise BotError("Category not found.")
        await audit(self.bot,interaction.guild,interaction.user.id,"category.rename",f"{category} => {new_name}")
        await answer(interaction,f"✅ Renamed **{category}** → **{new_name}**.")

    @app_commands.command(name="delete",description="Delete category and its stock — requires explicit confirmation")
    @app_commands.autocomplete(category=complete_categories)
    @manager_only()
    async def delete(self,interaction:discord.Interaction,category:str,confirm:bool=False):
        if not confirm: raise BotError("Set `confirm` to `True` to permanently delete this category AND ALL its stock.")
        num=await self.bot.db.exec("DELETE FROM categories WHERE guild_id=? AND name=? COLLATE NOCASE",(interaction.guild_id,category))
        if not num:raise BotError("Category not found.")
        await audit(self.bot,interaction.guild,interaction.user.id,"category.delete",category)
        await answer(interaction,f"✅ Deleted **{category}** and its remaining stock.")


@app_commands.guild_only()
@app_commands.default_permissions(manage_guild=True)
class Stock(commands.GroupCog, group_name="stock", group_description="Inspect and maintain private inventory"):
    def __init__(self,bot): self.bot=bot

    @app_commands.command(name="list",description="View stock quantities without exposing secret values")
    @manager_only()
    async def list_stock(self,interaction:discord.Interaction):
        rows=await self.bot.db.all("SELECT c.name,c.tier,c.cooldown_sec,COUNT(s.id) AS qty FROM categories c "
                                   "LEFT JOIN stock s ON s.category_id=c.id WHERE c.guild_id=? GROUP BY c.id ORDER BY c.name",
                                   (interaction.guild_id,))
        if not rows: raise BotError("No categories set up yet. Try `/add category`.")
        embed=discord.Embed(title="📦 Inventory overview",color=discord.Color.blurple())
        for r in rows[:25]:
            embed.add_field(name=f"{r['name']} · {r['tier']}",value=f"Stock: **{r['qty']}** | Cooldown: {r['cooldown_sec']//60}m",inline=True)
        await answer(interaction,embed=embed)

    @app_commands.command(name="export",description="Privately export decrypted available entries")
    @app_commands.autocomplete(category=complete_categories)
    @manager_only()
    async def export(self,interaction:discord.Interaction,category:str):
        await ensure_deferred(interaction)
        r=await self.bot.db.one("SELECT id FROM categories WHERE guild_id=? AND name=? COLLATE NOCASE",(interaction.guild_id,category))
        if not r:raise BotError("Category not found.")
        rows=await self.bot.db.all("SELECT cipher FROM stock WHERE category_id=? ORDER BY id LIMIT 10000",(r['id'],))
        if not rows:raise BotError("No remaining stock in this category.")
        content="\n".join(self.bot.db.cipher.decrypt(x['cipher'].encode()).decode() for x in rows)
        file=discord.File(io.BytesIO(content.encode()),filename=f"{validate_category(category)}_stock.txt")
        await audit(self.bot,interaction.guild,interaction.user.id,"stock.export",f"{category} ({len(rows)} entries)")
        await answer(interaction,"🔒 **Private stock export**. Keep this file secure and never post it publicly.",file=file)

    @app_commands.command(name="clear",description="Permanently empty stock from one category")
    @app_commands.autocomplete(category=complete_categories)
    @manager_only()
    async def clear(self,interaction:discord.Interaction,category:str,confirm:bool=False):
        if not confirm:raise BotError("This is irreversible. Set `confirm` to `True` to clear that category.")
        r=await self.bot.db.one("SELECT id FROM categories WHERE guild_id=? AND name=? COLLATE NOCASE",(interaction.guild_id,category))
        if not r:raise BotError("Category not found.")
        count=await self.bot.db.exec("DELETE FROM stock WHERE category_id=?",(r['id'],))
        await audit(self.bot,interaction.guild,interaction.user.id,"stock.clear",f"{category}: {count} entries")
        await answer(interaction,f"✅ Removed **{count}** available entries from **{category}**.")


@app_commands.guild_only()
class Gen(commands.GroupCog,group_name="gen",group_description="Generate from free or premium authorised inventory"):
    def __init__(self,bot):self.bot=bot

    async def _gen(self,interaction:discord.Interaction,category:str,required_tier:str):
        record=await self.bot.db.one("SELECT tier FROM categories WHERE guild_id=? AND name=? COLLATE NOCASE",
                                     (interaction.guild_id,category))
        if not record: raise BotError("Category not found. See `/gen categories`.")
        if record['tier'] != required_tier:
            raise BotError(f"This is a **{record['tier']}** category. Use `/gen {record['tier']}`.")
        config=await self.bot.db.setting(interaction.guild_id)
        member=interaction.user
        role_id=config['paid_role_id']
        has_role=bool(isinstance(member,discord.Member) and role_id and member.get_role(role_id))
        value,row=await self.bot.db.claim_stock(interaction.guild_id,category,interaction.user.id,has_role)
        await attachment_reply(interaction,f"✅ Your private {row['tier']} result — {row['name']}",value,"generated_entry.txt")

    @app_commands.command(name="free",description="Claim one free authorised access code")
    @app_commands.autocomplete(category=complete_categories)
    async def free(self,interaction:discord.Interaction,category:str):
        await self._gen(interaction,category,"free")

    @app_commands.command(name="paid",description="Claim one premium access code with a valid subscription or role")
    @app_commands.autocomplete(category=complete_categories)
    async def paid(self,interaction:discord.Interaction,category:str):
        await self._gen(interaction,category,"paid")

    @app_commands.command(name="history",description="See your last ten private generation events")
    async def history(self,interaction:discord.Interaction):
        rows=await self.bot.db.all("SELECT COALESCE(c.name,'removed-category') AS name, h.generated_at "
                                   "FROM generation_history h LEFT JOIN categories c ON c.id=h.category_id "
                                   "WHERE h.guild_id=? AND h.user_id=? ORDER BY h.id DESC LIMIT 10",
                                   (interaction.guild_id,interaction.user.id))
        if not rows: raise BotError("You haven't generated anything yet.")
        content='\n'.join(f"`{safe_snippet(r['name'],32)}` · <t:{r['generated_at']}:R>" for r in rows)
        await answer(interaction,"📋 **Your recent claims** (no secret values stored)\n"+content)

    @app_commands.command(name="categories",description="View free and premium categories with stock counts")
    async def categories(self,interaction:discord.Interaction):
        rows=await self.bot.db.all("SELECT c.name,c.tier,c.cooldown_sec,COUNT(s.id) AS qty FROM categories c "
                                   "LEFT JOIN stock s ON s.category_id=c.id WHERE c.guild_id=? GROUP BY c.id ORDER BY c.tier,c.name LIMIT 80",
                                   (interaction.guild_id,))
        if not rows:raise BotError("No categories available yet.")
        embed=discord.Embed(title="🛍️ Available categories",color=discord.Color.green())
        for tier in ('free','paid'):
            choices=[r for r in rows if r['tier']==tier]
            content="\n".join(f"`{safe_snippet(x['name'],32)}` · **{x['qty']}** available · {x['cooldown_sec']//60}m cooldown" for x in choices)
            embed.add_field(name=f"{'🆓 Free' if tier=='free' else '💎 Premium'}", value=(content[:1024] or "None"),inline=False)
        await answer(interaction,embed=embed)


async def setup(bot):
    for cls in (Add,Category,Stock,Gen): await bot.add_cog(cls(bot))
