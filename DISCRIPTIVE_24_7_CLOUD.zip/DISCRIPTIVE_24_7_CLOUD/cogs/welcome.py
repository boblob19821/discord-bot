"""Discriptive Welcomer Pro: tagged welcomes, image cards and editable templates.

All settings are per guild and persisted in welcome_profiles. Previous /welcome
configuration continues to work. User mentions are permitted only for the new
member, never for roles/everyone.
"""
from __future__ import annotations

import asyncio
import io
import logging
import re

import discord
from discord import app_commands
from discord.ext import commands

from helpers import answer, manager_only, audit, text_channel

log = logging.getLogger('yzvt.welcome')

TEMPLATES = {
    'marketplace': {
        'ping': '👋 Welcome to **{server}**, {mention}!',
        'title': '✨ WELCOME TO {server}',
        'description': (
            'Hey **{user}**! You are member **#{member_count}**.\n\n'
            '🎁 **Free generator:** {generator_channel}\n'
            '🛒 **Shop & products:** {shop_channel}\n'
            '📜 **Read our rules:** {rules_channel}\n\n'
            'Thanks for joining — enjoy your stay!'
        ),
        'footer': 'DISCRIPTIVE • Marketplace & Generator',
        'theme': 'midnight',
    },
    'minimal': {
        'ping': 'Welcome, {mention}! 👋',
        'title': 'Welcome to {server}',
        'description': 'Glad you are here, **{user}**! Check {shop_channel} and read {rules_channel}.',
        'footer': 'Member #{member_count}',
        'theme': 'minimal',
    },
    'hype': {
        'ping': '🚀 EVERYONE WELCOME {mention} TO **{server}**!',
        'title': '🔥 A NEW MEMBER HAS JOINED',
        'description': ('**{user}** just landed! You are member **#{member_count}**.\n\n'
                        '🎁 Check out {generator_channel}\n'
                        '🛍️ Browse {shop_channel}'),
        'footer': 'DISCRIPTIVE • WELCOME CREW',
        'theme': 'royal',
    },
    'clean': {
        'ping': '✨ {mention} just joined **{server}**',
        'title': 'WELCOME, {user}',
        'description': 'You are our **#{member_count}** member. Explore {shop_channel} and read {rules_channel}.',
        'footer': 'Good to have you here.',
        'theme': 'carbon',
    }
}
THEMES = ('midnight', 'royal', 'carbon', 'minimal')
CHANNEL_ALIASES = {
    'rules_channel': ('📜・rules', 'rules'),
    'shop_channel': ('🛍️・products', '🛒・shop', 'products', 'shop'),
    'generator_channel': ('🎁・free-generator', 'free-generator', 'generator'),
}
PLACEHOLDERS = ('{mention}', '{user}', '{username}', '{server}', '{member_count}',
                '{rules_channel}', '{shop_channel}', '{generator_channel}')


def get_template(profile, key: str):
    preset = TEMPLATES.get(profile['preset'], TEMPLATES['marketplace'])
    field = {'ping': 'ping_template', 'title': 'title_template',
             'description': 'description_template', 'footer': 'footer_template'}[key]
    return profile[field] if profile[field] is not None else preset[key]


def channel_value(guild, names):
    channel = next((c for n in names for c in guild.text_channels if c.name.casefold() == n.casefold()), None)
    return channel.mention if channel else '#'+names[-1]


def fill_template(text: str, member: discord.Member) -> str:
    """Fixed-token replacement, not unrestricted format or eval."""
    guild = member.guild
    raw = {
        'mention': member.mention,
        'user': discord.utils.escape_markdown(member.display_name),
        'username': discord.utils.escape_markdown(member.name),
        'server': discord.utils.escape_markdown(guild.name),
        'member_count': str(guild.member_count or 0),
    }
    raw.update({key: channel_value(guild, aliases) for key, aliases in CHANNEL_ALIASES.items()})
    return re.sub(r'\{([a-z_]+)\}', lambda m: raw.get(m.group(1), m.group(0)), text)


def welcome_embed(member, profile):
    title = fill_template(get_template(profile, 'title'), member)[:256]
    description = fill_template(get_template(profile, 'description'), member)[:4000]
    footer = fill_template(get_template(profile, 'footer'), member)[:2048]
    color = profile['color'] or '#27B7FF'
    try:
        colour = discord.Color(int(color.lstrip('#'), 16))
    except ValueError:
        colour = discord.Color.blue()
    embed = discord.Embed(title=title, description=description, color=colour)
    embed.set_footer(text=footer)
    embed.timestamp = discord.utils.utcnow()
    embed.set_thumbnail(url=member.display_avatar.url)
    return embed


async def image_file(member, profile):
    """Get user's real avatar and render PNG outside the event loop."""
    try:
        from welcome_cards import render_card
        try:
            avatar = await member.display_avatar.read()
        except (discord.HTTPException, OSError):
            avatar = None
        preset = TEMPLATES.get(profile['preset'], TEMPLATES['marketplace'])
        theme = profile['theme'] if profile['theme'] in THEMES else preset['theme']
        raw = await asyncio.to_thread(
            render_card, username=member.display_name, server_name=member.guild.name,
            member_count=member.guild.member_count or 0, avatar_bytes=avatar,
            brand=profile['brand'] or 'DISCRIPTIVE', theme=theme,
            accent=profile['color'] or '#27B7FF'
        )
        return discord.File(io.BytesIO(raw), filename='discriptive-welcome.png')
    except (ImportError, ValueError, OSError, MemoryError):
        log.exception('Welcome card unavailable; sending embed without image')
        return None


async def compose_welcome(member, profile, *, preview=False):
    """Create Discord welcome payload (no verification UI; RestoreCord manages access)."""
    embed = welcome_embed(member, profile)
    ping = fill_template(get_template(profile, 'ping'), member) if profile['mention_enabled'] else ''
    file = await image_file(member, profile) if profile['show_card'] else None
    if file:
        embed.set_image(url='attachment://discriptive-welcome.png')
    # The caller sets AllowedMentions to the joining member only. Previews disable pings.
    return ping or ('Welcome preview' if preview else ''), embed, file


@app_commands.guild_only()
class Welcome(commands.GroupCog, group_name='welcome', group_description='Discriptive Welcomer Pro templates and welcome cards'):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name='setup', description='Turn on welcome messages and select where to send them')
    @manager_only()
    async def setup_welcome(self, interaction: discord.Interaction,
                            channel: discord.TextChannel, auto_role: discord.Role | None = None):
        if auto_role and auto_role.name == '✅ Verified':
            await answer(interaction, 'Leave verification roles to RestoreCord. Do not assign Verified as a welcome auto-role.')
            return
        await self.bot.db.set_setting(interaction.guild_id, 'welcome_channel_id', channel.id)
        await self.bot.db.set_setting(interaction.guild_id, 'welcome_role_id', auto_role.id if auto_role else None)
        await self.bot.db.set_setting(interaction.guild_id, 'welcome_enabled', 1)
        await self.bot.db.welcome_profile(interaction.guild_id)
        await audit(self.bot, interaction.guild, interaction.user.id, 'welcome.setup', f'channel {channel.id}')
        await answer(interaction, f'✅ Welcomer enabled in {channel.mention}. Auto-role: '
                                 f'{auto_role.mention if auto_role else "off"}. Set Server Members Intent in the Developer Portal. '
                                 'Use `/welcome test` to preview before the next member joins.',
                     allowed_mentions=discord.AllowedMentions.none())

    @app_commands.command(name='template', description='Choose a pre-made welcome template (marketplace, minimal, hype, clean)')
    @app_commands.choices(preset=[app_commands.Choice(name=name.title(), value=name) for name in TEMPLATES])
    @manager_only()
    async def template(self, interaction: discord.Interaction, preset: app_commands.Choice[str]):
        await self.bot.db.set_welcome_profile(interaction.guild_id, preset=preset.value,
            theme=TEMPLATES[preset.value]['theme'], ping_template=None, title_template=None, description_template=None, footer_template=None)
        await answer(interaction, f'✅ Loaded the **{preset.value}** welcome template. '
                                 'Use `/welcome test` to preview it. Your card brand and colour are kept.')

    @app_commands.command(name='message', description='Set the welcome embed text (supports placeholders)')
    @manager_only()
    async def message(self, interaction: discord.Interaction, text: app_commands.Range[str, 1, 1600]):
        await self.bot.db.set_setting(interaction.guild_id, 'welcome_text', text)
        await self.bot.db.set_welcome_profile(interaction.guild_id, description_template=text)
        await audit(self.bot, interaction.guild, interaction.user.id, 'welcome.message', 'Description updated')
        await answer(interaction, '✅ Custom welcome embed text saved. Use `/welcome test` to preview.')

    @app_commands.command(name='ping', description='Set the message that tags the joining member')
    @manager_only()
    async def ping(self, interaction: discord.Interaction, text: app_commands.Range[str, 1, 400]):
        await self.bot.db.set_welcome_profile(interaction.guild_id, ping_template=text, mention_enabled=1)
        await answer(interaction, '✅ Welcome ping text saved. Include `{mention}` to actually tag the member.')

    @app_commands.command(name='headline', description='Change the welcome embed heading')
    @manager_only()
    async def headline(self, interaction: discord.Interaction, text: app_commands.Range[str, 1, 180]):
        await self.bot.db.set_welcome_profile(interaction.guild_id, title_template=text)
        await answer(interaction, '✅ Welcome headline updated.')

    @app_commands.command(name='footer', description='Change the footer of welcome embeds')
    @manager_only()
    async def footer(self, interaction: discord.Interaction, text: app_commands.Range[str, 1, 300]):
        await self.bot.db.set_welcome_profile(interaction.guild_id, footer_template=text)
        await answer(interaction, '✅ Welcome footer updated.')

    @app_commands.command(name='brand', description='Choose the brand name printed on the welcome card')
    @manager_only()
    async def brand(self, interaction: discord.Interaction, name: app_commands.Range[str, 1, 34]):
        await self.bot.db.set_welcome_profile(interaction.guild_id, brand=name)
        await answer(interaction, f'✅ Card branding is now **{discord.utils.escape_markdown(name)}**.')

    @app_commands.command(name='theme', description='Pick a welcome-card background theme')
    @app_commands.choices(style=[app_commands.Choice(name=name.title(), value=name) for name in THEMES])
    @manager_only()
    async def theme(self, interaction: discord.Interaction, style: app_commands.Choice[str]):
        await self.bot.db.set_welcome_profile(interaction.guild_id, theme=style.value)
        await answer(interaction, f'✅ Card theme set to **{style.value}**. Use `/welcome test` to preview.')

    @app_commands.command(name='colour', description='Set welcome card and embed accent (for example #27B7FF)')
    @manager_only()
    async def colour(self, interaction: discord.Interaction, hex_colour: str):
        from welcome_cards import normalise_hex
        try:
            accent = normalise_hex(hex_colour)
        except ValueError:
            await answer(interaction, '⚠️ Provide a six-digit colour, such as `#27B7FF`.')
            return
        await self.bot.db.set_welcome_profile(interaction.guild_id, color=accent)
        await answer(interaction, f'✅ Welcome accent colour set to `{accent}`.')

    @app_commands.command(name='card', description='Enable or disable the welcome picture')
    @manager_only()
    async def card(self, interaction: discord.Interaction, enabled: bool):
        await self.bot.db.set_welcome_profile(interaction.guild_id, show_card=int(enabled))
        await answer(interaction, f'✅ Welcome image card **{"enabled" if enabled else "disabled"}**.')

    @app_commands.command(name='tag', description='Enable or disable the joining member ping')
    @manager_only()
    async def tag(self, interaction: discord.Interaction, enabled: bool):
        await self.bot.db.set_welcome_profile(interaction.guild_id, mention_enabled=int(enabled))
        await answer(interaction, f'✅ Join ping **{"enabled" if enabled else "disabled"}**.')

    @app_commands.command(name='test', description='Preview the exact welcome design privately')
    @manager_only()
    async def test(self, interaction: discord.Interaction):
        profile = await self.bot.db.welcome_profile(interaction.guild_id)
        content, embed, file = await compose_welcome(interaction.user, profile, preview=True)
        kw = {'embed': embed, 'allowed_mentions': discord.AllowedMentions.none()}
        if file: kw['file'] = file
        await answer(interaction, content, **kw)

    @app_commands.command(name='status', description='Show current welcome settings and available placeholders')
    @manager_only()
    async def status(self, interaction: discord.Interaction):
        cfg = await self.bot.db.setting(interaction.guild_id)
        profile = await self.bot.db.welcome_profile(interaction.guild_id)
        await answer(interaction,
            '**👋 Discriptive Welcomer Pro**\n'
            f"Active: **{bool(cfg['welcome_enabled'])}** · Channel: <#{cfg['welcome_channel_id']}>\n"
            f"Template: `{profile['preset']}` · Theme: `{profile['theme']}` · Brand: `{profile['brand']}` · Accent: `{profile['color']}`\n"
            f"Card: **{bool(profile['show_card'])}** · Tag: **{bool(profile['mention_enabled'])}**\n"
            f"Placeholders: {' '.join('`'+x+'`' for x in PLACEHOLDERS)}",
            allowed_mentions=discord.AllowedMentions.none())

    @app_commands.command(name='disable', description='Turn off welcome messages and auto-role')
    @manager_only()
    async def disable(self, interaction: discord.Interaction):
        await self.bot.db.set_setting(interaction.guild_id, 'welcome_enabled', 0)
        await audit(self.bot, interaction.guild, interaction.user.id, 'welcome.disable', '')
        await answer(interaction, '✅ Welcome automation disabled.')

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        cfg = await self.bot.db.setting(member.guild.id)
        if not cfg['welcome_enabled']:
            return
        if cfg['welcome_role_id']:
            role = member.guild.get_role(cfg['welcome_role_id'])
            if role and role.name != '✅ Verified':
                try:
                    await member.add_roles(role, reason='Welcomer starter role')
                except (discord.Forbidden, discord.HTTPException):
                    log.warning('Auto-role assignment failed in %s', member.guild.id)
        channel = text_channel(member.guild, cfg['welcome_channel_id'])
        if channel is None:
            return
        profile = await self.bot.db.welcome_profile(member.guild.id)
        ping, embed, file = await compose_welcome(member, profile)
        options = {'content': ping or None, 'embed': embed,
                   'allowed_mentions': discord.AllowedMentions(users=[member], roles=False, everyone=False)}
        if file:
            options['file'] = file
        try:
            await channel.send(**options)
        except (discord.Forbidden, discord.HTTPException):
            log.exception('Unable to post welcome for %s in guild %s', member.id, member.guild.id)


async def setup(bot):
    await bot.add_cog(Welcome(bot))
