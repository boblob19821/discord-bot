"""Idempotent, permission-aware Discord marketplace server builder."""
import asyncio
import json
import discord
from discord import app_commands
from discord.ext import commands
from helpers import answer

BLUE=discord.Color.from_rgb(88,101,242)
CATEGORIES={
 "📌・START HERE": ["👋・welcome","📜・rules","📢・announcements","📖・how-to-buy","📊・server-status"],
 "🛒・THE MARKETPLACE": ["🛍️・products","💷・price-list","🆕・new-arrivals","🎉・deals","🛒・order-here"],
 "⚡・GENERATOR": ["🎁・free-generator","💎・premium-generator","🔑・redeem-keys","📦・stock-updates","📋・generator-guide"],
 "👑・PREMIUM LOUNGE": ["💬・premium-chat","✨・premium-news"],
 "⭐・REPUTATION": ["⭐・vouches","💬・feedback","🏆・completed-orders"],
 "🎫・SUPPORT": ["🎟️・open-ticket","❓・faq","📑・refund-policy"],
 "🌐・COMMUNITY": ["💬・general","🤖・bot-commands","🎁・giveaways","💡・suggestions"],
 "🔒・STAFF HQ": ["🛡️・staff-chat","📥・stock-management","📑・order-logs","🔑・key-logs","🎫・ticket-logs","⚙️・admin-logs"],
}
ROLES=[("👑 Owner",discord.Color.gold()),("🛡️ Administrator",discord.Color.red()),("🔧 Staff",discord.Color.orange()),("💎 Premium",discord.Color.purple()),("🛍️ Customer",discord.Color.green()),("✅ Verified",discord.Color.blue())]
READONLY={"👋・welcome","📜・rules","📢・announcements","📖・how-to-buy","📊・server-status","🛍️・products","💷・price-list","🆕・new-arrivals","🎉・deals","📦・stock-updates","📋・generator-guide","⭐・vouches","🏆・completed-orders","❓・faq","📑・refund-policy","✨・premium-news"}

def existing_named(guild,name,cls):
 return discord.utils.get(guild.channels,name=name) if cls is None else next((x for x in guild.channels if x.name==name and isinstance(x,cls)),None)

class Market(commands.GroupCog,group_name="market",group_description="Build and manage your marketplace server"):
 def __init__(self,bot):self.bot=bot
 async def check(self,interaction):
  if not interaction.guild or not interaction.user.guild_permissions.manage_guild:
   await answer(interaction,"⛔ Manage Server permission is required.");return False
  me=interaction.guild.me
  if not me.guild_permissions.manage_channels or not me.guild_permissions.manage_roles:
   await answer(interaction,"⛔ Give the bot Manage Channels and Manage Roles permissions first.");return False
  return True
 @app_commands.command(name="preview",description="Preview the marketplace layout without changing anything")
 @app_commands.guild_only()
 async def preview(self,interaction:discord.Interaction):
  if not await self.check(interaction):return
  e=discord.Embed(title="🛒 YZVT Marketplace — Preview",description="Run `/market build confirm: YES` to create missing roles and channels. Existing matching names are reused. No channels or roles are deleted.",color=BLUE)
  for category,channels in CATEGORIES.items():e.add_field(name=category,value=f"{len(channels)} channels",inline=True)
  e.add_field(name="Roles",value=", ".join(r for r,_ in ROLES),inline=False)
  await answer(interaction,embed=e)
 @app_commands.command(name="build",description="Create missing shop, generator, staff and support sections")
 @app_commands.guild_only()
 @app_commands.describe(confirm="Type YES to create the server layout")
 async def build(self,interaction:discord.Interaction,confirm:str):
  if not await self.check(interaction):return
  if confirm!='YES':await answer(interaction,"No changes made. Type `YES` exactly to confirm.");return
  g=interaction.guild;me=g.me
  made_roles=[];made_channels=[];issues=[]
  roles={}
  for name,color in ROLES:
   role=discord.utils.get(g.roles,name=name)
   if role is None:
    try:role=await g.create_role(name=name,color=color,reason=f"Marketplace setup requested by {interaction.user}");made_roles.append(name)
    except discord.HTTPException as e:issues.append(f"Role {name}: {type(e).__name__}");continue
   roles[name]=role
  staff=[roles[k] for k in ('👑 Owner','🛡️ Administrator','🔧 Staff') if k in roles]
  premium=roles.get('💎 Premium')
  for catname,channels in CATEGORIES.items():
   private=catname.startswith('🔒');premium_only=catname.startswith('👑')
   cat=discord.utils.get(g.categories,name=catname)
   if cat is None:
    overwrites={g.default_role:discord.PermissionOverwrite(view_channel=not(private or premium_only))}
    if private:
     for role in staff:overwrites[role]=discord.PermissionOverwrite(view_channel=True,send_messages=True,read_message_history=True)
    if premium_only:
     if premium:overwrites[premium]=discord.PermissionOverwrite(view_channel=True,send_messages=True)
     for role in staff:overwrites[role]=discord.PermissionOverwrite(view_channel=True,send_messages=True)
    try:cat=await g.create_category(catname,overwrites=overwrites,reason="YZVT marketplace setup");made_channels.append(catname)
    except discord.HTTPException as e:issues.append(f"Category {catname}: {type(e).__name__}");continue
   for name in channels:
    if existing_named(g,name,discord.TextChannel):continue
    perms={}
    if name in READONLY:perms[g.default_role]=discord.PermissionOverwrite(send_messages=False)
    try:
     await g.create_text_channel(name,category=cat,overwrites=perms,reason="YZVT marketplace setup")
     made_channels.append(name)
    except discord.HTTPException as e:issues.append(f"Channel {name}: {type(e).__name__}")
    await asyncio.sleep(.15)
  cfg=await self.bot.db.setting(g.id)
  assignments={'paid_role_id':premium.id if premium else None,'staff_role_id':roles['🔧 Staff'].id if '🔧 Staff' in roles else None,'welcome_channel_id':getattr(existing_named(g,'👋・welcome',discord.TextChannel),'id',None),'vouch_channel_id':getattr(existing_named(g,'⭐・vouches',discord.TextChannel),'id',None),'ticket_log_id':getattr(existing_named(g,'🎫・ticket-logs',discord.TextChannel),'id',None),'audit_channel_id':getattr(existing_named(g,'⚙️・admin-logs',discord.TextChannel),'id',None),'ticket_category_id':getattr(discord.utils.get(g.categories,name='🎫・SUPPORT'),'id',None)}
  for field,value in assignments.items():
   if value and not cfg[field]:
    try:await self.bot.db.set_setting(g.id,field,value)
    except Exception as e:issues.append(f"Setting {field}: {type(e).__name__}")
  e=discord.Embed(title="✅ Marketplace setup finished",description=f"Created **{len(made_roles)}** roles and **{len(made_channels)}** channels/categories. Existing matching items were left intact.",color=BLUE)
  if issues:e.add_field(name="Needs attention",value="\n".join(issues[:12])[:1024],inline=False)
  e.add_field(name="Next steps",value="Use `/market panels` to post shop and generator panels. Configure tickets with `/ticket` commands. Review channel permissions and set your staff roles manually.",inline=False)
  await answer(interaction,embed=e)
 @app_commands.command(name="panels",description="Post shop, generator and information embeds into matching channels")
 @app_commands.guild_only()
 async def panels(self,interaction:discord.Interaction):
  if not await self.check(interaction):return
  g=interaction.guild;sent=[];failed=[]
  panels=[('🛍️・products','🛒 YZVT Marketplace','Browse our current digital products and services. To order, open a support ticket in #open-ticket. Only authorised goods and services are sold.'),('🎁・free-generator','🎁 Free Generator','Use `/gen free` to claim available free stock. Check `/stock` for availability and follow the cooldown rules.'),('💎・premium-generator','💎 Premium Generator','Use `/gen paid` with a valid premium license or eligible premium role. Redeem a purchased key using `/key redeem`.'),('🔑・redeem-keys','🔑 Redeem Your Premium Key','Use `/key redeem` privately. Never share your license key with anyone.'),('🎟️・open-ticket','🎫 Shop Support','Need to buy something or ask about an order? Use the ticket panel configured with the bot’s `/ticket` commands. Staff will assist privately.'),('📜・rules','📜 Marketplace Rules','No fraud, stolen accounts, unauthorised credentials, spam, harassment or chargeback abuse. Sell only products you own or are authorised to distribute. Follow Discord rules and applicable law.'),('📑・refund-policy','📑 Refunds & Disputes','Check the product listing and applicable consumer rights before buying. Open a ticket for order problems. Staff should state refund terms clearly before purchase.')]
  for name,title,body in panels:
   ch=existing_named(g,name,discord.TextChannel)
   if not ch:failed.append(name+' missing');continue
   try:await ch.send(embed=discord.Embed(title=title,description=body,color=BLUE));sent.append(name)
   except discord.HTTPException:failed.append(name+' permission error')
  await answer(interaction,f"✅ Posted {len(sent)} panels. "+(f"Issues: {', '.join(failed)}" if failed else "Run this only when you want to post new copies."))

async def setup(bot):await bot.add_cog(Market(bot))
