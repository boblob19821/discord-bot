"""Private support ticket system with persistent buttons and transcripts."""
import io
import re
import sqlite3
from datetime import timedelta
import discord
from discord import app_commands
from discord.ext import commands
from core import BotError, now, stamp, unix_fmt, safe_snippet
from helpers import ensure_deferred, answer, manager_only, is_manager, audit, text_channel


def slug(text: str) -> str:
    return re.sub(r"[^a-z0-9-]+", "-",text.lower()).strip('-')[:35] or 'support'


class OpenTicketModal(discord.ui.Modal,title="Create a support ticket"):
    async def on_error(self, interaction:discord.Interaction, error:Exception):
        import logging
        logging.getLogger("yzvt.ticket").error("Ticket modal failed",exc_info=(type(error),error,error.__traceback__))
        try:
            await answer(interaction, f"⚠️ {error}" if isinstance(error,BotError) else "⚠️ Could not create the ticket. Please contact staff or check the bot console.")
        except discord.HTTPException:
            pass

    subject=discord.ui.TextInput(label="Subject",placeholder="e.g. Order help, access support",max_length=80)
    details=discord.ui.TextInput(label="How can the team help?",style=discord.TextStyle.paragraph,max_length=1300)

    def __init__(self,bot):
        super().__init__()
        self.bot=bot

    async def on_submit(self,interaction:discord.Interaction):
        await self.bot.get_cog('Ticket').create_ticket(interaction,str(self.subject),str(self.details))


class TicketPanelView(discord.ui.View):
    async def on_error(self, interaction:discord.Interaction, error:Exception, item:discord.ui.Item):
        import logging
        logging.getLogger("yzvt.ticket").error("Ticket panel failed",exc_info=(type(error),error,error.__traceback__))
        try:
            await answer(interaction,f"⚠️ {error}" if isinstance(error,BotError) else "⚠️ Could not open the ticket panel. Ask staff to check permissions.")
        except discord.HTTPException:
            pass

    def __init__(self,bot):
        super().__init__(timeout=None)
        self.bot=bot

    @discord.ui.button(label="Open a Ticket",emoji="🎫",style=discord.ButtonStyle.primary,custom_id="yzvt:ticket:open:v1")
    async def open(self,interaction:discord.Interaction,button:discord.ui.Button):
        await interaction.response.send_modal(OpenTicketModal(self.bot))


class TicketControlsView(discord.ui.View):
    async def on_error(self, interaction:discord.Interaction, error:Exception, item:discord.ui.Item):
        import logging
        logging.getLogger("yzvt.ticket").error("Ticket control failed",exc_info=(type(error),error,error.__traceback__))
        try:
            await answer(interaction,f"⚠️ {error}" if isinstance(error,BotError) else "⚠️ Ticket action failed. Ask staff to check the bot console.")
        except discord.HTTPException:
            pass

    def __init__(self,bot):
        super().__init__(timeout=None)
        self.bot=bot

    @discord.ui.button(label="Claim",emoji="📌",style=discord.ButtonStyle.secondary,custom_id="yzvt:ticket:claim:v1")
    async def claim(self,interaction:discord.Interaction,button:discord.ui.Button):
        await self.bot.get_cog('Ticket').claim_ticket(interaction)

    @discord.ui.button(label="Close",emoji="🔒",style=discord.ButtonStyle.danger,custom_id="yzvt:ticket:close:v1")
    async def close(self,interaction:discord.Interaction,button:discord.ui.Button):
        await self.bot.get_cog('Ticket').close_ticket(interaction,"Closed via ticket button")


@app_commands.guild_only()
class Ticket(commands.GroupCog,group_name="ticket",group_description="Open, manage and close support tickets"):
    def __init__(self,bot):self.bot=bot

    async def ticket_by_channel(self,interaction):
        if not interaction.guild or not interaction.channel:
            raise BotError("Tickets can only be managed inside a server ticket channel.")
        row=await self.bot.db.one("SELECT * FROM tickets WHERE guild_id=? AND channel_id=? AND status='open'",
                                  (interaction.guild_id,interaction.channel.id))
        if not row:raise BotError("This command is only available inside an open ticket channel.")
        return row

    async def staff(self,interaction):
        cfg=await self.bot.db.setting(interaction.guild_id)
        return is_manager(interaction) or bool(cfg['staff_role_id'] and isinstance(interaction.user,discord.Member) and interaction.user.get_role(cfg['staff_role_id']))

    async def create_ticket(self,interaction,subject,details):
        if not interaction.guild:raise BotError("Tickets are server-only.")
        if not subject.strip() or not details.strip():raise BotError("Include both a subject and details.")
        await ensure_deferred(interaction)
        guild=interaction.guild
        cfg=await self.bot.db.setting(guild.id)
        if not cfg['staff_role_id'] or not cfg['ticket_category_id'] or not cfg['ticket_log_id']:
            raise BotError("Ticket system isn't configured. A manager must use `/ticket setup` first.")
        category=guild.get_channel(cfg['ticket_category_id']) if cfg['ticket_category_id'] else None
        if cfg['ticket_category_id'] and not isinstance(category,discord.CategoryChannel):
            raise BotError("Configured ticket category cannot be found. Ask an admin to run `/ticket setup`.")
        if not guild.me.guild_permissions.manage_channels:
            raise BotError("Bot needs **Manage Channels** permission to create tickets.")
        try:
            cur=await self.bot.db.exec("INSERT INTO tickets(guild_id,user_id,subject,details,status,opened_at) VALUES(?,?,?,?,?,?)",
                                       (guild.id,interaction.user.id,subject[:80],details[:1300],"pending",stamp(now())))
            # sqlite3 rowcount is 1, fetch pending reservation by guild + user
        except sqlite3.IntegrityError:
            existing=await self.bot.db.one("SELECT channel_id FROM tickets WHERE guild_id=? AND user_id=? AND status IN ('open','pending')",
                                           (guild.id,interaction.user.id))
            channel=guild.get_channel(existing['channel_id']) if existing and existing['channel_id'] else None
            raise BotError(f"You already have a ticket open{f' in {channel.mention}' if channel else ''}.")
        pending=await self.bot.db.one("SELECT id FROM tickets WHERE guild_id=? AND user_id=? AND status='pending'",
                                      (guild.id,interaction.user.id))
        id_=pending['id']
        staff_role=guild.get_role(cfg['staff_role_id']) if cfg['staff_role_id'] else None
        if not staff_role:
            await self.bot.db.exec("DELETE FROM tickets WHERE id=? AND status='pending'",(id_,))
            raise BotError("Support staff role was removed. Run `/ticket setup` again.")
        overwrites={guild.default_role:discord.PermissionOverwrite(view_channel=False),
                    interaction.user:discord.PermissionOverwrite(view_channel=True,send_messages=True,read_message_history=True),
                    guild.me:discord.PermissionOverwrite(view_channel=True,send_messages=True,manage_channels=True,read_message_history=True)}
        if staff_role:
            overwrites[staff_role]=discord.PermissionOverwrite(view_channel=True,send_messages=True,read_message_history=True)
        channel=None
        try:
            channel=await guild.create_text_channel(
                name=f"ticket-{id_}-{slug(interaction.user.display_name)}"[:95], category=category,
                overwrites=overwrites, reason=f"Ticket #{id_} opened by {interaction.user.id}")
            await self.bot.db.exec("UPDATE tickets SET channel_id=?,status='open' WHERE id=?",(channel.id,id_))
        except Exception:
            await self.bot.db.exec("DELETE FROM tickets WHERE id=? AND status='pending'",(id_,))
            if channel:
                try:await channel.delete(reason="Ticket setup failed")
                except discord.HTTPException:pass
            raise
        embed=discord.Embed(title=f"🎫 Support Ticket #{id_}",description=f"**Subject:** {safe_snippet(subject,80)}\n\n{safe_snippet(details,1300)}",color=discord.Color.blurple())
        embed.set_footer(text=f"Opened by {interaction.user.display_name} • Use buttons or /ticket commands")
        await channel.send(content=staff_role.mention if staff_role else None,embed=embed,
                           view=TicketControlsView(self.bot),allowed_mentions=discord.AllowedMentions(roles=True,users=False,everyone=False))
        await audit(self.bot,guild,interaction.user.id,"ticket.open",f"#{id_} {channel.id}")
        await answer(interaction,f"✅ Ticket **#{id_}** created: {channel.mention}")

    async def build_transcript(self,channel):
        lines=[f"TICKET TRANSCRIPT | #{channel.name} | {now().isoformat()}","="*65]
        async for msg in channel.history(oldest_first=True,limit=500):
            when=msg.created_at.strftime('%Y-%m-%d %H:%M UTC')
            text=(msg.content or '[No accessible text]')
            attachments=" ".join(a.url for a in msg.attachments)
            lines.append(f"[{when}] {msg.author} ({msg.author.id}): {text[:5000]} {attachments}".strip())
        return "\n".join(lines).encode('utf-8')

    async def close_ticket(self,interaction,reason:str):
        ticket=await self.ticket_by_channel(interaction)
        if interaction.user.id!=ticket['user_id'] and not await self.staff(interaction):
            raise BotError("Only the ticket creator or support staff can close a ticket.")
        await ensure_deferred(interaction)
        ch=interaction.channel
        txt=await self.build_transcript(ch)
        cfg=await self.bot.db.setting(interaction.guild_id)
        log=text_channel(interaction.guild,cfg['ticket_log_id'])
        # Only support staff should have access to the log channel.
        if log:
            try:
                await log.send(content=f"🔒 Ticket **#{ticket['id']}** closed by <@{interaction.user.id}>. "
                                       f"Owner: <@{ticket['user_id']}>. Reason: {safe_snippet(reason,300)}",
                               file=discord.File(io.BytesIO(txt),filename=f"ticket-{ticket['id']}.txt"),
                               allowed_mentions=discord.AllowedMentions.none())
            except discord.HTTPException:
                await answer(interaction,"⚠️ Couldn't save the transcript to the log channel. Ticket was NOT closed; check bot permissions.")
                return
        updated=await self.bot.db.exec("UPDATE tickets SET status='closed',closed_at=?,closed_by=?,close_reason=? WHERE id=? AND status='open'",
                                      (stamp(now()),interaction.user.id,reason[:400],ticket['id']))
        if not updated: raise BotError("This ticket has already been closed.")
        await audit(self.bot,interaction.guild,interaction.user.id,"ticket.close",f"#{ticket['id']}")
        try:
            owner=interaction.guild.get_member(ticket['user_id']) or await self.bot.fetch_user(ticket['user_id'])
            await owner.send(f"Your support ticket **#{ticket['id']}** in **{interaction.guild.name}** was closed. "
                             f"You can leave verified feedback with `/vouch submit` using ticket ID `{ticket['id']}`.")
        except (discord.HTTPException,discord.Forbidden):pass
        await answer(interaction,f"✅ Ticket **#{ticket['id']}** closed. Transcript saved to the configured log channel (if set).")
        try:await ch.delete(reason=f"Ticket #{ticket['id']} closed by {interaction.user.id}")
        except discord.HTTPException:pass

    async def claim_ticket(self,interaction):
        ticket=await self.ticket_by_channel(interaction)
        if not await self.staff(interaction):raise BotError("Only support staff can claim tickets.")
        if ticket['claimed_by'] and ticket['claimed_by']!=interaction.user.id:
            raise BotError(f"This ticket is already claimed by <@{ticket['claimed_by']}>")
        await self.bot.db.exec("UPDATE tickets SET claimed_by=? WHERE id=?",(interaction.user.id,ticket['id']))
        await audit(self.bot,interaction.guild,interaction.user.id,"ticket.claim",f"#{ticket['id']}")
        await answer(interaction,f"📌 Claimed ticket **#{ticket['id']}**.")
        await interaction.channel.send(f"📌 {interaction.user.mention} is now handling this ticket.")

    @app_commands.command(name="open",description="Open a private support ticket")
    async def open(self,interaction:discord.Interaction,subject:str,details:str):
        await self.create_ticket(interaction,subject,details)

    @app_commands.command(name="panel",description="Post a persistent ticket-opening button in a channel")
    @manager_only()
    async def panel(self,interaction:discord.Interaction,channel:discord.TextChannel):
        embed=discord.Embed(title="🎟️ Support Centre",description="Need support? Click the button below to open a private ticket with our team.\n\n• Private channel\n• Staff assistance\n• Ticket tracking and closure",color=discord.Color.blurple())
        msg=await channel.send(embed=embed,view=TicketPanelView(self.bot))
        await audit(self.bot,interaction.guild,interaction.user.id,"ticket.panel",f"channel {channel.id} message {msg.id}")
        await answer(interaction,f"✅ Ticket panel posted in {channel.mention}.")

    @app_commands.command(name="setup",description="Configure ticket location, transcript logs and support staff role")
    @manager_only()
    async def setup_ticket(self,interaction:discord.Interaction,category:discord.CategoryChannel,
                           staff_role:discord.Role,log_channel:discord.TextChannel):
        for field,value in [('ticket_category_id',category.id),('staff_role_id',staff_role.id),('ticket_log_id',log_channel.id)]:
            await self.bot.db.set_setting(interaction.guild_id,field,value)
        await audit(self.bot,interaction.guild,interaction.user.id,"ticket.setup","Updated support configuration")
        await answer(interaction,f"✅ Tickets will be created in **{category.name}**. Staff: {staff_role.mention}. Transcripts: {log_channel.mention}.\nEnsure the log channel is **staff-only**.",allowed_mentions=discord.AllowedMentions.none())

    @app_commands.command(name="close",description="Close this ticket, keeping a transcript if logging is configured")
    async def close(self,interaction:discord.Interaction,reason:str="Resolved"):
        await self.close_ticket(interaction,reason)

    @app_commands.command(name="claim",description="Claim the current ticket as a support staff member")
    async def claim(self,interaction:discord.Interaction):
        await self.claim_ticket(interaction)

    @app_commands.command(name="add_user",description="Invite another member into this private ticket")
    async def add_user(self,interaction:discord.Interaction,member:discord.Member):
        await self.ticket_by_channel(interaction)
        if not await self.staff(interaction):raise BotError("Only staff can invite ticket participants.")
        await interaction.channel.set_permissions(member,view_channel=True,send_messages=True,read_message_history=True,
                                                   reason=f"Ticket participant added by {interaction.user.id}")
        await answer(interaction,f"✅ Added {member.mention} to the ticket.",allowed_mentions=discord.AllowedMentions.none())

    @app_commands.command(name="remove_user",description="Remove a guest from this private ticket")
    async def remove_user(self,interaction:discord.Interaction,member:discord.Member):
        ticket=await self.ticket_by_channel(interaction)
        if not await self.staff(interaction):raise BotError("Only staff can remove ticket participants.")
        if member.id==ticket['user_id']:raise BotError("You cannot remove the ticket creator.")
        await interaction.channel.set_permissions(member,overwrite=None,reason=f"Ticket participant removed by {interaction.user.id}")
        await answer(interaction,f"✅ Removed {member.mention}'s ticket-specific permissions.",allowed_mentions=discord.AllowedMentions.none())

    @app_commands.command(name="rename",description="Change this ticket channel name")
    async def rename(self,interaction:discord.Interaction,name:str):
        ticket=await self.ticket_by_channel(interaction)
        if not await self.staff(interaction):raise BotError("Only support staff can rename tickets.")
        await interaction.channel.edit(name=f"ticket-{ticket['id']}-{slug(name)}")
        await answer(interaction,"✅ Ticket channel renamed.")

    @app_commands.command(name="transcript",description="Privately export the current ticket transcript")
    async def transcript(self,interaction:discord.Interaction):
        ticket=await self.ticket_by_channel(interaction)
        if not await self.staff(interaction):raise BotError("Only support staff can export transcripts.")
        await ensure_deferred(interaction)
        payload=await self.build_transcript(interaction.channel)
        await answer(interaction,"🔒 Ticket transcript (private).",file=discord.File(io.BytesIO(payload),filename=f"ticket-{ticket['id']}.txt"))

    @app_commands.command(name="stats",description="View support ticket activity")
    @manager_only()
    async def stats(self,interaction:discord.Interaction):
        rows=await self.bot.db.all("SELECT status,COUNT(*) AS n FROM tickets WHERE guild_id=? GROUP BY status",(interaction.guild_id,))
        vals={r['status']:r['n'] for r in rows}
        await answer(interaction,f"🎟️ **Support statistics**\nOpen: **{vals.get('open',0)}**\nClosed: **{vals.get('closed',0)}**\nPending: **{vals.get('pending',0)}**")


async def setup(bot):await bot.add_cog(Ticket(bot))
