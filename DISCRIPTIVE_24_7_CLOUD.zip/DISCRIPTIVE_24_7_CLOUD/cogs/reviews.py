"""Verified, one-per-closed-ticket vouches with rating summaries."""
import sqlite3
import discord
from discord import app_commands
from discord.ext import commands
from core import BotError, now, stamp, safe_snippet
from helpers import answer, manager_only, audit, text_channel


@app_commands.guild_only()
class Vouch(commands.GroupCog,group_name="vouch",group_description="Verified feedback from completed support tickets"):
    def __init__(self,bot):self.bot=bot

    @app_commands.command(name="submit",description="Leave one verified review for a support ticket you completed")
    @app_commands.choices(rating=[app_commands.Choice(name=f"{x} star{'s' if x>1 else ''}",value=x) for x in range(1,6)])
    @app_commands.checks.cooldown(3,60,key=lambda i:(i.guild_id,i.user.id))
    async def submit(self,interaction:discord.Interaction,ticket_id:int,rating:app_commands.Choice[int],comment:app_commands.Range[str,5,900]):
        ticket=await self.bot.db.one("SELECT id,user_id,status FROM tickets WHERE id=? AND guild_id=?",
                                     (ticket_id,interaction.guild_id))
        if not ticket or ticket['user_id']!=interaction.user.id or ticket['status']!='closed':
            raise BotError("A vouch must refer to **your own closed support ticket** in this server.")
        if ticket['user_id']==self.bot.user.id:raise BotError("The bot cannot leave a vouch.")
        try:
            await self.bot.db.exec("INSERT INTO vouches(guild_id,ticket_id,user_id,rating,comment,posted_at) VALUES(?,?,?,?,?,?)",
                                   (interaction.guild_id,ticket_id,interaction.user.id,rating.value,comment,stamp(now())))
        except sqlite3.IntegrityError:raise BotError("That ticket has already been reviewed.")
        cfg=await self.bot.db.setting(interaction.guild_id)
        ch=text_channel(interaction.guild,cfg['vouch_channel_id'])
        if ch:
            embed=discord.Embed(title="⭐ New verified customer feedback",description=safe_snippet(comment,900),color=discord.Color.gold())
            embed.add_field(name="Rating",value="⭐"*rating.value,inline=True)
            embed.add_field(name="Verified ticket",value=f"#{ticket_id}",inline=True)
            embed.set_footer(text=f"Submitted by {interaction.user.display_name}")
            try:
                posted=await ch.send(embed=embed,allowed_mentions=discord.AllowedMentions.none())
                await self.bot.db.exec("UPDATE vouches SET message_id=? WHERE guild_id=? AND ticket_id=?",
                                       (posted.id,interaction.guild_id,ticket_id))
            except discord.HTTPException:pass
        await audit(self.bot,interaction.guild,interaction.user.id,"vouch.submit",f"ticket #{ticket_id}; {rating.value}/5")
        await answer(interaction,f"✅ Thank you! Your **{rating.value}/5** verified review was saved.")

    @app_commands.command(name="stats",description="See average rating and number of verified vouches")
    async def stats(self,interaction:discord.Interaction):
        row=await self.bot.db.one("SELECT COUNT(*) AS n,AVG(rating) AS avg FROM vouches WHERE guild_id=?",(interaction.guild_id,))
        avg=f"{row['avg']:.2f}" if row['avg'] is not None else "N/A"
        await answer(interaction,f"⭐ **Server reputation**\nVerified vouches: **{row['n']}**\nAverage rating: **{avg}/5**\n\nOnly verified closed-ticket reviews are counted.")

    @app_commands.command(name="recent",description="Display recent verified feedback")
    async def recent(self,interaction:discord.Interaction):
        rows=await self.bot.db.all("SELECT ticket_id,user_id,rating,comment,posted_at FROM vouches WHERE guild_id=? ORDER BY id DESC LIMIT 5",(interaction.guild_id,))
        if not rows:raise BotError("No verified vouches yet.")
        embed=discord.Embed(title="⭐ Latest verified vouches",color=discord.Color.gold())
        for row in rows:
            embed.add_field(name=f"{'⭐'*row['rating']} · Ticket #{row['ticket_id']}",
                            value=f"{safe_snippet(row['comment'],350)}\nBy <@{row['user_id']}> · <t:{row['posted_at']}:R>",inline=False)
        await answer(interaction,embed=embed,allowed_mentions=discord.AllowedMentions.none())

    @app_commands.command(name="set_channel",description="Configure where verified vouches are automatically posted")
    @manager_only()
    async def set_channel(self,interaction:discord.Interaction,channel:discord.TextChannel):
        await self.bot.db.set_setting(interaction.guild_id,'vouch_channel_id',channel.id)
        await audit(self.bot,interaction.guild,interaction.user.id,"vouch.set_channel",f"channel {channel.id}")
        await answer(interaction,f"✅ Verified vouches will be posted in {channel.mention}.")

    @app_commands.command(name="remove",description="Remove an abusive vouch by ID (not based on rating)")
    @manager_only()
    async def remove(self,interaction:discord.Interaction,vouch_id:int,reason:str):
        row=await self.bot.db.one("SELECT * FROM vouches WHERE id=? AND guild_id=?",(vouch_id,interaction.guild_id))
        if not row:raise BotError("Vouch ID not found. Use `/vouch lookup` to find it.")
        cfg=await self.bot.db.setting(interaction.guild_id)
        channel=text_channel(interaction.guild,cfg['vouch_channel_id'])
        if channel and row['message_id']:
            try:
                message=await channel.fetch_message(row['message_id'])
                await message.delete()
            except (discord.NotFound,discord.Forbidden,discord.HTTPException):pass
        await self.bot.db.exec("DELETE FROM vouches WHERE id=? AND guild_id=?",(vouch_id,interaction.guild_id))
        await audit(self.bot,interaction.guild,interaction.user.id,"vouch.remove",f"#{vouch_id}; reason {reason[:90]}")
        await answer(interaction,"✅ Vouch removed. The bot also attempted to remove its channel embed.")

    @app_commands.command(name="lookup",description="List recent feedback IDs for moderation")
    @manager_only()
    async def lookup(self,interaction:discord.Interaction):
        rows=await self.bot.db.all("SELECT id,ticket_id,user_id,rating FROM vouches WHERE guild_id=? ORDER BY id DESC LIMIT 15",(interaction.guild_id,))
        msg="\n".join(f"ID `{x['id']}` · Ticket #{x['ticket_id']} · User {x['user_id']} · {x['rating']}/5" for x in rows)
        await answer(interaction,"**Recent vouch IDs**\n"+(msg or "No reviews yet."))


async def setup(bot):await bot.add_cog(Vouch(bot))
