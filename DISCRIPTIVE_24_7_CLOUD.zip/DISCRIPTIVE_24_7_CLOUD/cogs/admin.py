"""Admin controls, health/dashboard, and user-facing help."""
import discord
from discord import app_commands
from discord.ext import commands
from core import BotError, now, stamp
from helpers import answer, manager_only, audit
from cogs.inventory import complete_categories


@app_commands.guild_only()
@app_commands.default_permissions(manage_guild=True)
class Admin(commands.GroupCog,group_name="admin",group_description="Configure your bot and inspect server usage"):
    def __init__(self,bot):self.bot=bot

    @app_commands.command(name="dashboard",description="Show stock, usage, premium and support overview")
    @manager_only()
    async def dashboard(self,interaction:discord.Interaction):
        gid=interaction.guild_id
        cat=await self.bot.db.one("SELECT COUNT(*) n FROM categories WHERE guild_id=?",(gid,))
        stock=await self.bot.db.one("SELECT COUNT(*) n FROM stock WHERE guild_id=?",(gid,))
        gen=await self.bot.db.one("SELECT COUNT(*) n FROM generation_history WHERE guild_id=?",(gid,))
        paid=await self.bot.db.one("SELECT COUNT(*) n FROM licenses WHERE guild_id=? AND expires_at>?",(gid,stamp(now())))
        tickets=await self.bot.db.one("SELECT COUNT(*) n FROM tickets WHERE guild_id=? AND status='open'",(gid,))
        vouches=await self.bot.db.one("SELECT COUNT(*) n FROM vouches WHERE guild_id=?",(gid,))
        embed=discord.Embed(title="📊 YZVT Control Panel",description="Live server database totals",color=discord.Color.blurple())
        for title,num in (("Categories",cat['n']),("Available stock",stock['n']),("Total generated",gen['n']),
                          ("Active premium users",paid['n']),("Open tickets",tickets['n']),("Verified vouches",vouches['n'])):
            embed.add_field(name=title,value=f"**{num:,}**",inline=True)
        embed.set_footer(text="Stock secrets and full key values are never logged")
        await answer(interaction,embed=embed)

    @app_commands.command(name="settings",description="View all configured server channels and roles")
    @manager_only()
    async def settings(self,interaction:discord.Interaction):
        cfg=await self.bot.db.setting(interaction.guild_id)
        labels={'paid_role_id':'Paid role','ticket_category_id':'Ticket category','ticket_log_id':'Ticket log',
                'staff_role_id':'Support staff','vouch_channel_id':'Vouch channel','welcome_channel_id':'Welcome channel',
                'welcome_role_id':'Welcome auto-role','audit_channel_id':'Audit channel'}
        embed=discord.Embed(title="⚙️ Current server configuration",color=discord.Color.blurple())
        for field,title in labels.items():
            embed.add_field(name=title,value=f"`{cfg[field] or 'Not set'}`",inline=True)
        embed.add_field(name="Welcomer enabled",value=str(bool(cfg['welcome_enabled'])),inline=True)
        await answer(interaction,embed=embed)

    @app_commands.command(name="paid_role",description="Grant paid generation access to holders of this Discord role")
    @manager_only()
    async def paid_role(self,interaction:discord.Interaction,role:discord.Role):
        await self.bot.db.set_setting(interaction.guild_id,'paid_role_id',role.id)
        await audit(self.bot,interaction.guild,interaction.user.id,"admin.paid_role",f"role {role.id}")
        await answer(interaction,f"✅ Members with {role.mention} may use `/gen paid` without a key-based license.",allowed_mentions=discord.AllowedMentions.none())

    @app_commands.command(name="remove_paid_role",description="Disable premium access via Discord roles (keys still work)")
    @manager_only()
    async def remove_paid_role(self,interaction:discord.Interaction):
        await self.bot.db.set_setting(interaction.guild_id,'paid_role_id',None)
        await audit(self.bot,interaction.guild,interaction.user.id,"admin.remove_paid_role","")
        await answer(interaction,"✅ Role-based premium disabled. Active key licenses still work.")

    @app_commands.command(name="audit_channel",description="Set the audit channel for administrative activity")
    @manager_only()
    async def audit_channel(self,interaction:discord.Interaction,channel:discord.TextChannel):
        await self.bot.db.set_setting(interaction.guild_id,'audit_channel_id',channel.id)
        await audit(self.bot,interaction.guild,interaction.user.id,"admin.audit_channel",f"channel {channel.id}")
        await answer(interaction,f"✅ Admin audit events will be sent to {channel.mention}. Make it staff-only.")

    @app_commands.command(name="reset_cooldown",description="Reset an individual's category generator cooldown")
    @app_commands.autocomplete(category=complete_categories)
    @manager_only()
    async def reset_cooldown(self,interaction:discord.Interaction,member:discord.Member,category:str):
        cat=await self.bot.db.one("SELECT id FROM categories WHERE guild_id=? AND name=? COLLATE NOCASE",(interaction.guild_id,category))
        if not cat:raise BotError("Category not found.")
        affected=await self.bot.db.exec("DELETE FROM claims WHERE guild_id=? AND category_id=? AND user_id=?",
                                        (interaction.guild_id,cat['id'],member.id))
        await audit(self.bot,interaction.guild,interaction.user.id,"admin.reset_cooldown",f"member {member.id} category {category}")
        await answer(interaction,f"✅ Cooldown reset for {member.mention} in **{category}** ({affected} records).",allowed_mentions=discord.AllowedMentions.none())

    @app_commands.command(name="audit",description="View recent local administration events")
    @manager_only()
    async def audit_log(self,interaction:discord.Interaction):
        rows=await self.bot.db.all("SELECT actor_id,action,detail,created_at FROM audit WHERE guild_id=? ORDER BY id DESC LIMIT 10",
                                   (interaction.guild_id,))
        text="\n".join(f"<t:{r['created_at']}:R> · `{r['action']}` · {r['actor_id']} · {r['detail'][:60]}" for r in rows)
        await answer(interaction,"**Recent admin activity**\n"+(text or "None."),allowed_mentions=discord.AllowedMentions.none())

    @app_commands.command(name="sync", description="Refresh all slash commands for the configured server or global scope")
    @manager_only()
    async def sync(self, interaction:discord.Interaction):
        if self.bot.test_guild and interaction.guild_id != self.bot.test_guild:
            raise BotError("Command syncing is configured for a different test server.")
        count=await self.bot.sync_commands()
        await audit(self.bot,interaction.guild,interaction.user.id,"admin.sync",f"Refreshed {count} slash roots")
        await answer(interaction,f"✅ Refreshed **{count}** slash command roots. Renamed or deleted commands in this scope were replaced. Your database is unchanged.")

    @app_commands.command(name="prune",description="Clear expired premium subscription records")
    @manager_only()
    async def prune(self,interaction:discord.Interaction):
        n=await self.bot.db.exec("DELETE FROM licenses WHERE guild_id=? AND expires_at<=?",(interaction.guild_id,stamp(now())))
        await audit(self.bot,interaction.guild,interaction.user.id,"admin.prune",f"{n} expired licenses")
        await answer(interaction,f"✅ Removed **{n}** expired license records.")


class System(commands.Cog):
    def __init__(self,bot):self.bot=bot

    @app_commands.command(name="help",description="View all bot command groups and setup shortcuts")
    @app_commands.guild_only()
    async def help(self,interaction:discord.Interaction):
        embed=discord.Embed(title="🛡️ YZVT • Generator & Support",description="Professional slash-command inventory and customer support toolkit.\n**Use `/` in Discord to see parameter descriptions and autocomplete.**",color=discord.Color.blurple())
        embed.add_field(name="🛍️ Generation",value="`/gen free`, `/gen paid`, `/gen categories`",inline=False)
        embed.add_field(name="💎 Premium keys",value="`/key redeem`, `/key status`, `/key create`, `/key grant`, `/key revoke`, `/key overview`",inline=False)
        embed.add_field(name="📦 Inventory",value="`/add category`, `/add catagory`, `/add stock`, `/category edit`, `/stock list`, `/stock export`, `/stock clear`",inline=False)
        embed.add_field(name="🎟️ Support",value="`/ticket setup`, `/ticket panel`, `/ticket open`, `/ticket close`, `/ticket claim`, `/ticket transcript`",inline=False)
        embed.add_field(name="⭐ Vouches",value="`/vouch submit`, `/vouch recent`, `/vouch stats`, `/vouch set_channel`",inline=False)
        embed.add_field(name="👋 Welcome",value="`/welcome setup`, `/welcome message`, `/welcome test`, `/welcome disable`",inline=False)
        embed.add_field(name="⚙️ Admin",value="`/admin dashboard`, `/admin settings`, `/admin paid_role`, `/admin audit_channel`, `/admin sync`, `/status set`, `/status show`, `/status clear`",inline=False)
        embed.set_footer(text="Restricted commands require Manage Server. Inventory must be yours to distribute.")
        await answer(interaction,embed=embed)

    @app_commands.command(name="ping",description="See gateway connection latency")
    @app_commands.guild_only()
    async def ping(self,interaction:discord.Interaction):
        await answer(interaction,f"🏓 Gateway latency: **{self.bot.latency*1000:.0f} ms**")


async def setup(bot):
    await bot.add_cog(Admin(bot))
    await bot.add_cog(System(bot))
