"""Owner-only, restart-persistent bot presence controls."""
import json
import discord
from discord import app_commands
from discord.ext import commands
from core import BotError
from helpers import answer, audit

DEFAULT_PRESENCE={"text":"","type":"watching","state":"online"}
ACTIVITY_TYPES={"custom","playing","watching","listening","competing"}
PRESENCE_STATES={"online","idle","dnd","invisible"}


def parse_presence(raw):
    """Discard malformed stored configurations rather than crashing the bot."""
    try:
        value=json.loads(raw) if raw else DEFAULT_PRESENCE
        if (not isinstance(value,dict)
            or value.get('type') not in ACTIVITY_TYPES
            or value.get('state') not in PRESENCE_STATES
            or not isinstance(value.get('text'),str)
            or len(value['text'])>120):
            return DEFAULT_PRESENCE.copy()
        return value
    except (TypeError,ValueError):
        return DEFAULT_PRESENCE.copy()


def make_activity(cfg):
    name=cfg['text'].strip()
    if not name:
        return None
    mode=cfg['type']
    if mode=='custom':
        return discord.CustomActivity(name=name)
    if mode=='playing':
        return discord.Game(name=name)
    return discord.Activity(type=getattr(discord.ActivityType,mode),name=name)


def status_owner_only():
    """Bot presence is global, so guild moderators cannot hijack it."""
    async def predicate(interaction:discord.Interaction):
        bot=interaction.client
        expected=bot.owner_id_config
        if expected:
            authorized=interaction.user.id==expected
        else:
            authorized=bool(interaction.guild and interaction.guild.owner_id==interaction.user.id
                            and (not bot.test_guild or interaction.guild_id==bot.test_guild))
        if not authorized:
            raise BotError("Only the configured bot OWNER_ID (or server owner if not set) may change the bot status.")
        return True
    return app_commands.check(predicate)


@app_commands.guild_only()
class Status(commands.GroupCog,group_name="status",group_description="Custom bot activity and presence controls"):
    def __init__(self,bot):self.bot=bot

    @app_commands.command(name="set",description="Set and save the bot activity (persists across restarts)")
    @app_commands.choices(activity=[app_commands.Choice(name=label,value=value) for label,value in
                           (("Custom status","custom"),("Playing","playing"),("Watching","watching"),
                            ("Listening","listening"),("Competing","competing"))],
                          presence=[app_commands.Choice(name=label,value=value) for label,value in
                            (("Online","online"),("Idle","idle"),("Do Not Disturb","dnd"),("Invisible","invisible"))])
    @status_owner_only()
    async def set(self,interaction:discord.Interaction,text:app_commands.Range[str,1,120],
                  activity:app_commands.Choice[str],presence:app_commands.Choice[str]|None=None):
        cfg={"text":str(text),"type":activity.value,"state":presence.value if presence else "online"}
        # Validate by constructing activity before saving anything.
        obj=make_activity(cfg)
        await self.bot.change_presence(activity=obj,status=getattr(discord.Status,cfg['state']))
        await self.bot.db.exec("INSERT INTO bot_settings(name,value) VALUES ('presence',?) "
                               "ON CONFLICT(name) DO UPDATE SET value=excluded.value",(json.dumps(cfg),))
        await audit(self.bot,interaction.guild,interaction.user.id,"status.set",f"{cfg['type']} ({cfg['state']})")
        await answer(interaction,f"✅ Bot status saved: **{discord.utils.escape_markdown(text)}** ({cfg['type']}, {cfg['state']}). Will restore on restart.")

    @app_commands.command(name="clear",description="Clear saved custom activity and return to online")
    @status_owner_only()
    async def clear(self,interaction:discord.Interaction):
        await self.bot.change_presence(activity=None,status=discord.Status.online)
        await self.bot.db.exec("DELETE FROM bot_settings WHERE name='presence'")
        await audit(self.bot,interaction.guild,interaction.user.id,"status.clear","")
        await answer(interaction,"✅ Custom activity cleared. The bot will appear online after every restart.")

    @app_commands.command(name="show",description="View the currently configured bot activity")
    async def show(self,interaction:discord.Interaction):
        row=await self.bot.db.one("SELECT value FROM bot_settings WHERE name='presence'")
        cfg=parse_presence(row['value'] if row else None)
        await answer(interaction,f"🔎 **Bot status**\nType: **{cfg['type']}**\nText: **{discord.utils.escape_markdown(cfg['text']) or 'None'}**\nPresence: **{cfg['state']}**\nSaved across restarts: **Yes**")


async def setup(bot):
    await bot.add_cog(Status(bot))
