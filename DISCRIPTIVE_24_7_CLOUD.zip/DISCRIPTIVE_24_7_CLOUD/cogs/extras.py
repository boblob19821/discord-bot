"""Marketplace additions. All credits are non-cash, non-withdrawable store points."""
import asyncio
import io
import json
import secrets
import sqlite3
import time
from datetime import datetime, timezone, timedelta
import discord
from discord import app_commands
from discord.ext import commands, tasks
from helpers import answer, manager_only

def ts(): return int(time.time())

class Extras(commands.Cog):
    def __init__(self, bot):
        self.bot=bot
        self.invites={}
        self.maintenance.start()

    async def cog_load(self):
        statements=[
        "CREATE TABLE IF NOT EXISTS wallets(guild INTEGER,user INTEGER,balance INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(guild,user))",
        "CREATE TABLE IF NOT EXISTS wallet_events(id INTEGER PRIMARY KEY,guild INTEGER,user INTEGER,delta INTEGER,actor INTEGER,reason TEXT,created INTEGER)",
        "CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY,guild INTEGER,buyer INTEGER,item TEXT,price INTEGER,status TEXT,created INTEGER,updated INTEGER)",
        "CREATE TABLE IF NOT EXISTS coupons(code TEXT,guild INTEGER,credit INTEGER,uses INTEGER,expires INTEGER,PRIMARY KEY(code,guild))",
        "CREATE TABLE IF NOT EXISTS giveaways(id INTEGER PRIMARY KEY,guild INTEGER,channel INTEGER,message INTEGER,prize TEXT,ends INTEGER,winners INTEGER,ended INTEGER DEFAULT 0)",
        "CREATE TABLE IF NOT EXISTS entries(giveaway INTEGER,user INTEGER,PRIMARY KEY(giveaway,user))",
        "CREATE TABLE IF NOT EXISTS stock_alerts(guild INTEGER,category INTEGER,threshold INTEGER,channel INTEGER,last_alert INTEGER DEFAULT 0,PRIMARY KEY(guild,category))",
        "CREATE TABLE IF NOT EXISTS invites_seen(guild INTEGER,inviter INTEGER,member INTEGER,code TEXT,joined INTEGER,PRIMARY KEY(guild,member))",
        "CREATE TABLE IF NOT EXISTS security(guild INTEGER PRIMARY KEY,enabled INTEGER DEFAULT 1,join_limit INTEGER DEFAULT 12,window_sec INTEGER DEFAULT 60)",
        "CREATE TABLE IF NOT EXISTS join_events(guild INTEGER,member INTEGER,created INTEGER)"
        ]
        for sql in statements: await self.bot.db.exec(sql)
        for guild in self.bot.guilds: await self.cache_invites(guild)

    def cog_unload(self): self.maintenance.cancel()

    async def cache_invites(self,guild):
        try:self.invites[guild.id]={i.code:(i.uses or 0,i.inviter.id if i.inviter else 0) for i in await guild.invites()}
        except (discord.Forbidden,discord.HTTPException):pass

    @commands.Cog.listener()
    async def on_guild_join(self,guild): await self.cache_invites(guild)

    @commands.Cog.listener()
    async def on_member_join(self,member):
        g=member.guild; old=self.invites.get(g.id,{})
        try:
            new={i.code:(i.uses or 0,i.inviter.id if i.inviter else 0) for i in await g.invites()}
            used=next(((code,v[1]) for code,v in new.items() if v[0]>old.get(code,(0,0))[0]),None)
            self.invites[g.id]=new
            if used: await self.bot.db.exec('INSERT OR REPLACE INTO invites_seen VALUES(?,?,?,?,?)',(g.id,used[1],member.id,used[0],ts()))
        except (discord.Forbidden,discord.HTTPException): pass
        await self.bot.db.exec('INSERT INTO join_events VALUES(?,?,?)',(g.id,member.id,ts()))
        await self.bot.db.exec('DELETE FROM join_events WHERE created<?',(ts()-3600,))
        row=await self.bot.db.one('SELECT * FROM security WHERE guild=?',(g.id,))
        if row and row['enabled']:
            count=await self.bot.db.one('SELECT COUNT(*) n FROM join_events WHERE guild=? AND created>=?',(g.id,ts()-row['window_sec']))
            if count['n']>=row['join_limit']:
                channel=g.system_channel
                if channel:
                    try: await channel.send(f'⚠️ Join spike detected: {count["n"]} joins in {row["window_sec"]} seconds. Review recent members.',allowed_mentions=discord.AllowedMentions.none())
                    except discord.HTTPException:pass

    async def credit(self,guild,user,delta,actor,reason):
        async with self.bot.db.lock:
            db=self.bot.db.conn
            await db.execute('BEGIN IMMEDIATE')
            try:
                await db.execute('INSERT OR IGNORE INTO wallets(guild,user,balance) VALUES(?,?,0)',(guild,user))
                cur=await db.execute('UPDATE wallets SET balance=balance+? WHERE guild=? AND user=? AND balance+?>=0',(delta,guild,user,delta))
                if cur.rowcount!=1:raise ValueError('Insufficient credits')
                await db.execute('INSERT INTO wallet_events(guild,user,delta,actor,reason,created) VALUES(?,?,?,?,?,?)',(guild,user,delta,actor,reason,ts()))
                await db.commit()
            except Exception:
                await db.rollback();raise

    wallet=app_commands.Group(name='wallet',description='Non-withdrawable store credits')
    @wallet.command(name='balance',description='Check store credits')
    async def balance(self,i:discord.Interaction):
        r=await self.bot.db.one('SELECT balance FROM wallets WHERE guild=? AND user=?',(i.guild_id,i.user.id))
        await answer(i,f'💳 Your store credits: **{r["balance"] if r else 0}**')
    @wallet.command(name='adjust',description='Admin: add or remove store credits')
    @manager_only()
    async def adjust(self,i:discord.Interaction,member:discord.Member,amount:int,reason:str):
        if amount==0 or abs(amount)>1000000:return await answer(i,'Amount must be between -1,000,000 and 1,000,000, excluding zero.')
        try:await self.credit(i.guild_id,member.id,amount,i.user.id,reason[:150])
        except ValueError as e:return await answer(i,str(e))
        await answer(i,f'Updated {member.mention} by {amount:+} credits.');
    @wallet.command(name='history',description='Your recent credit activity')
    async def history(self,i:discord.Interaction):
        rows=await self.bot.db.all('SELECT delta,reason FROM wallet_events WHERE guild=? AND user=? ORDER BY id DESC LIMIT 10',(i.guild_id,i.user.id))
        await answer(i,'\n'.join(f'{r["delta"]:+} — {r["reason"]}' for r in rows) or 'No transactions yet.')

    order=app_commands.Group(name='order',description='Track shop orders')
    @order.command(name='create',description='Staff: record a customer order')
    @manager_only()
    async def order_create(self,i:discord.Interaction,buyer:discord.Member,item:str,price:int):
        if price<0:return await answer(i,'Price cannot be negative.')
        await self.bot.db.exec('INSERT INTO orders(guild,buyer,item,price,status,created,updated) VALUES(?,?,?,?,?,?,?)',(i.guild_id,buyer.id,item[:120],price,'pending',ts(),ts()))
        row=await self.bot.db.one('SELECT id FROM orders WHERE guild=? AND buyer=? ORDER BY id DESC LIMIT 1',(i.guild_id,buyer.id))
        await answer(i,f'Order #{row["id"]} created for {buyer.mention}.')
    @order.command(name='status',description='Staff: update order status')
    @manager_only()
    @app_commands.choices(status=[app_commands.Choice(name=x,value=x) for x in ('pending','paid','processing','delivered','cancelled','refunded')])
    async def order_status(self,i:discord.Interaction,order_id:int,status:app_commands.Choice[str]):
        n=await self.bot.db.exec('UPDATE orders SET status=?,updated=? WHERE id=? AND guild=?',(status.value,ts(),order_id,i.guild_id))
        await answer(i,'Order updated.' if n else 'Order not found.')
    @order.command(name='view',description='View your order (staff can view any)')
    async def order_view(self,i:discord.Interaction,order_id:int):
        r=await self.bot.db.one('SELECT * FROM orders WHERE id=? AND guild=?',(order_id,i.guild_id))
        if not r or (r['buyer']!=i.user.id and not i.user.guild_permissions.manage_guild):return await answer(i,'Order not found.')
        await answer(i,f'📦 Order #{r["id"]} • {r["item"]} • {r["price"]} credits • **{r["status"]}**')

    promo=app_commands.Group(name='promo',description='Store credit promotions')
    @promo.command(name='create',description='Admin: create limited-use credit coupon')
    @manager_only()
    async def promo_create(self,i:discord.Interaction,credits:int,uses:int,hours:int=24):
        if not 1<=credits<=100000 or not 1<=uses<=10000 or not 1<=hours<=8760:return await answer(i,'Invalid limits.')
        code='DSP-'+secrets.token_urlsafe(12)
        await self.bot.db.exec('INSERT INTO coupons VALUES(?,?,?,?,?)',(code,i.guild_id,credits,uses,ts()+hours*3600))
        await answer(i,f'Coupon: `{code}` • {credits} credits • {uses} uses • expires in {hours}h. Keep private until sharing.')
    @promo.command(name='redeem',description='Redeem a store credit coupon')
    async def promo_redeem(self,i:discord.Interaction,code:str):
        async with self.bot.db.lock:
            db=self.bot.db.conn;await db.execute('BEGIN IMMEDIATE')
            try:
                cur=await db.execute('SELECT * FROM coupons WHERE code=? AND guild=? AND uses>0 AND expires>?',(code,i.guild_id,ts()))
                row=await cur.fetchone()
                if not row:raise ValueError('Invalid or expired coupon.')
                await db.execute('UPDATE coupons SET uses=uses-1 WHERE code=? AND guild=?',(code,i.guild_id))
                await db.execute('INSERT OR IGNORE INTO wallets(guild,user,balance) VALUES(?,?,0)',(i.guild_id,i.user.id))
                await db.execute('UPDATE wallets SET balance=balance+? WHERE guild=? AND user=?',(row['credit'],i.guild_id,i.user.id))
                await db.execute('INSERT INTO wallet_events(guild,user,delta,actor,reason,created) VALUES(?,?,?,?,?,?)',(i.guild_id,i.user.id,row['credit'],i.user.id,'coupon',ts()))
                await db.commit()
            except Exception as e:
                await db.rollback();return await answer(i,str(e))
        await answer(i,f'Redeemed {row["credit"]} store credits!')

    giveaway=app_commands.Group(name='giveaway',description='Prize draws')
    @giveaway.command(name='start',description='Admin: start a giveaway in this channel')
    @manager_only()
    async def giveaway_start(self,i:discord.Interaction,prize:str,hours:int=24,winners:int=1):
        if not 1<=hours<=720 or not 1<=winners<=20:return await answer(i,'Hours: 1–720; winners: 1–20.')
        msg=await i.channel.send(f'🎉 **GIVEAWAY** — {discord.utils.escape_mentions(prize[:150])}\nEnds <t:{ts()+hours*3600}:R>. Enter with `/giveaway enter` using message ID: (posted below)',allowed_mentions=discord.AllowedMentions.none())
        await msg.edit(content=f'🎉 **GIVEAWAY** — {discord.utils.escape_mentions(prize[:150])}\nEnds <t:{ts()+hours*3600}:R>. Enter with `/giveaway enter message_id:{msg.id}`')
        await self.bot.db.exec('INSERT INTO giveaways(guild,channel,message,prize,ends,winners) VALUES(?,?,?,?,?,?)',(i.guild_id,i.channel_id,msg.id,prize[:150],ts()+hours*3600,winners))
        await answer(i,'Giveaway created.')
    @giveaway.command(name='enter',description='Enter an active giveaway')
    async def giveaway_enter(self,i:discord.Interaction,message_id:str):
        try:mid=int(message_id)
        except ValueError:return await answer(i,'Invalid message ID.')
        r=await self.bot.db.one('SELECT * FROM giveaways WHERE guild=? AND message=? AND ended=0 AND ends>?',(i.guild_id,mid,ts()))
        if not r:return await answer(i,'Giveaway not found or ended.')
        n=await self.bot.db.exec('INSERT OR IGNORE INTO entries VALUES(?,?)',(r['id'],i.user.id))
        await answer(i,'🎟️ Entry confirmed!' if n else 'You have already entered.')

    restock=app_commands.Group(name='restock',description='Stock alerts')
    @restock.command(name='alert',description='Admin: set low-stock alert for category')
    @manager_only()
    async def restock_alert(self,i:discord.Interaction,category_id:int,threshold:int,channel:discord.TextChannel):
        r=await self.bot.db.one('SELECT id FROM categories WHERE id=? AND guild_id=?',(category_id,i.guild_id))
        if not r or threshold<0:return await answer(i,'Invalid category or threshold.')
        await self.bot.db.exec('INSERT OR REPLACE INTO stock_alerts(guild,category,threshold,channel,last_alert) VALUES(?,?,?,?,0)',(i.guild_id,category_id,threshold,channel.id))
        await answer(i,'Low-stock alert configured (checked every 5 minutes).')

    subscription=app_commands.Group(name='subscription',description='Premium expiry information')
    @subscription.command(name='info',description='Check premium expiration')
    async def subscription_info(self,i:discord.Interaction):
        r=await self.bot.db.one('SELECT expires_at FROM licenses WHERE guild_id=? AND user_id=?',(i.guild_id,i.user.id))
        await answer(i,f'👑 Premium expires <t:{r["expires_at"]}:F> (<t:{r["expires_at"]}:R>)' if r and r['expires_at']>ts() else 'No active premium subscription.')
    @subscription.command(name='expiring',description='Admin: list memberships expiring within 7 days')
    @manager_only()
    async def subscription_expiring(self,i:discord.Interaction):
        rows=await self.bot.db.all('SELECT user_id,expires_at FROM licenses WHERE guild_id=? AND expires_at BETWEEN ? AND ? LIMIT 20',(i.guild_id,ts(),ts()+604800))
        await answer(i,'\n'.join(f'<@{r["user_id"]}> — <t:{r["expires_at"]}:R>' for r in rows) or 'None expiring soon.')

    security=app_commands.Group(name='security',description='Anti-abuse settings')
    @security.command(name='join-alerts',description='Admin: configure join-spike warnings')
    @manager_only()
    async def security_alerts(self,i:discord.Interaction,enabled:bool,limit:int=12,window_seconds:int=60):
        if not 2<=limit<=500 or not 10<=window_seconds<=3600:return await answer(i,'Invalid limit/window.')
        await self.bot.db.exec('INSERT OR REPLACE INTO security VALUES(?,?,?,?)',(i.guild_id,int(enabled),limit,window_seconds))
        await answer(i,'Join-spike alerts updated. This warns staff; it does not auto-ban members.')

    invite=app_commands.Group(name='invite',description='Invite tracking (requires Manage Server on bot)')
    @invite.command(name='stats',description='See tracked invites for a member')
    async def invite_stats(self,i:discord.Interaction,member:discord.Member=None):
        member=member or i.user
        r=await self.bot.db.one('SELECT COUNT(*) n FROM invites_seen WHERE guild=? AND inviter=?',(i.guild_id,member.id))
        await answer(i,f'🔗 {member.display_name}: **{r["n"]}** recorded joins. Tracking begins after the bot is online; vanity invites may not resolve.')
    @invite.command(name='refresh',description='Admin: refresh invite cache')
    @manager_only()
    async def invite_refresh(self,i:discord.Interaction):
        await self.cache_invites(i.guild);await answer(i,'Invite cache refreshed.')

    backup=app_commands.Group(name='backup',description='Database backups')
    @backup.command(name='create',description='Owner only: export encrypted-stock database')
    async def backup_create(self,i:discord.Interaction):
        if i.user.id!=self.bot.owner_id_config:return await answer(i,'Only the configured bot owner can export the database.')
        async with self.bot.db.lock:
            target=sqlite3.connect(':memory:')
            await self.bot.db.conn.backup(target)
            dump='\n'.join(target.iterdump());target.close()
        payload=dump.encode()
        if len(payload)>7_000_000:return await answer(i,'Database too large for Discord attachment. Back up the .db file locally.')
        await answer(i,'Private database export. **Keep your .env encryption key separately and securely.**',file=discord.File(io.BytesIO(payload),filename='discriptive_backup.sql'))

    @tasks.loop(minutes=5)
    async def maintenance(self):
        if not self.bot.is_ready():return
        for r in await self.bot.db.all('SELECT * FROM stock_alerts'):
            n=await self.bot.db.one('SELECT COUNT(*) n FROM stock WHERE category_id=? AND guild_id=?',(r['category'],r['guild']))
            if n and n['n']<=r['threshold'] and ts()-r['last_alert']>21600:
                guild=self.bot.get_guild(r['guild']);ch=guild.get_channel(r['channel']) if guild else None
                if ch:
                    try:
                        await ch.send(f'📦 Low stock: category #{r["category"]} has **{n["n"]}** items remaining.',allowed_mentions=discord.AllowedMentions.none())
                        await self.bot.db.exec('UPDATE stock_alerts SET last_alert=? WHERE guild=? AND category=?',(ts(),r['guild'],r['category']))
                    except discord.HTTPException:pass
        for r in await self.bot.db.all('SELECT * FROM giveaways WHERE ended=0 AND ends<=?',(ts(),)):
            rows=await self.bot.db.all('SELECT user FROM entries WHERE giveaway=? ORDER BY RANDOM() LIMIT ?',(r['id'],r['winners']))
            await self.bot.db.exec('UPDATE giveaways SET ended=1 WHERE id=? AND ended=0',(r['id'],))
            guild=self.bot.get_guild(r['guild']);ch=guild.get_channel(r['channel']) if guild else None
            if ch:
                try:await ch.send(f'🎉 Giveaway ended: **{discord.utils.escape_mentions(r["prize"])}**\nWinner(s): '+(', '.join(f'<@{x["user"]}>' for x in rows) if rows else 'No entries'),allowed_mentions=discord.AllowedMentions.none())
                except discord.HTTPException:pass


    @wallet.command(name='leaderboard',description='Top 10 credit balances in this server')
    @manager_only()
    async def wallet_leaderboard(self,i:discord.Interaction):
        rows=await self.bot.db.all('SELECT user,balance FROM wallets WHERE guild=? ORDER BY balance DESC LIMIT 10',(i.guild_id,))
        await answer(i,'💳 **Wallet leaderboard**\\n'+'\\n'.join(f'<@{r["user"]}> — {r["balance"]} credits' for r in rows) if rows else 'No wallets yet.')

    @order.command(name='mine',description='See your ten most recent orders')
    async def order_mine(self,i:discord.Interaction):
        rows=await self.bot.db.all('SELECT id,item,status FROM orders WHERE guild=? AND buyer=? ORDER BY id DESC LIMIT 10',(i.guild_id,i.user.id))
        await answer(i,'📦 **Your orders**\\n'+'\\n'.join(f'#{r["id"]} • {discord.utils.escape_markdown(r["item"])} • {r["status"]}' for r in rows) if rows else 'You have no orders.')

    @order.command(name='queue',description='Staff: show pending and processing orders')
    @manager_only()
    async def order_queue(self,i:discord.Interaction):
        rows=await self.bot.db.all("SELECT id,buyer,item,status FROM orders WHERE guild=? AND status IN ('pending','paid','processing') ORDER BY created ASC LIMIT 20",(i.guild_id,))
        await answer(i,'📦 **Open order queue**\\n'+'\\n'.join(f'#{r["id"]} • <@{r["buyer"]}> • {discord.utils.escape_markdown(r["item"])} • {r["status"]}' for r in rows) if rows else 'No open orders.')

    @giveaway.command(name='list',description='Show active giveaways in this server')
    async def giveaway_list(self,i:discord.Interaction):
        rows=await self.bot.db.all('SELECT id,prize,ends FROM giveaways WHERE guild=? AND ended=0 ORDER BY ends ASC LIMIT 15',(i.guild_id,))
        await answer(i,'🎁 **Active giveaways**\\n'+'\\n'.join(f'#{r["id"]} • {discord.utils.escape_markdown(r["prize"])} • ends <t:{r["ends"]}:R>' for r in rows) if rows else 'No active giveaways.')

    @giveaway.command(name='cancel',description='Staff: cancel an active giveaway')
    @manager_only()
    async def giveaway_cancel(self,i:discord.Interaction,giveaway_id:int):
        n=await self.bot.db.exec('UPDATE giveaways SET ended=1 WHERE id=? AND guild=? AND ended=0',(giveaway_id,i.guild_id))
        await answer(i,'Giveaway cancelled.' if n else 'Active giveaway not found.')

    @invite.command(name='leaderboard',description='Top tracked inviters')
    async def invite_leaderboard(self,i:discord.Interaction):
        rows=await self.bot.db.all('SELECT inviter,COUNT(*) n FROM invites_seen WHERE guild=? GROUP BY inviter ORDER BY n DESC LIMIT 10',(i.guild_id,))
        await answer(i,'🔗 **Invite leaderboard**\\n'+'\\n'.join(f'<@{r["inviter"]}> — {r["n"]} joins' for r in rows) if rows else 'No tracked invites yet.')

    @security.command(name='overview',description='Staff: show current join-alert settings')
    @manager_only()
    async def security_overview(self,i:discord.Interaction):
        r=await self.bot.db.one('SELECT * FROM security WHERE guild=?',(i.guild_id,))
        await answer(i,f'🛡️ Join alerts: **{"Enabled" if r and r["enabled"] else "Disabled"}**\\nLimit: **{r["join_limit"] if r else 12}** joins in **{r["window_sec"] if r else 60}** seconds.\\nThis feature warns only; it does not automatically punish members.')

    @maintenance.before_loop
    async def before_maintenance(self):await self.bot.wait_until_ready()

async def setup(bot):await bot.add_cog(Extras(bot))
