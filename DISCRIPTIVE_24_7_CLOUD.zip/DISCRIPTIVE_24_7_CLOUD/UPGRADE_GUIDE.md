# Discriptive eight-feature upgrade

Use this as an update to the uploaded bot, not a new database. Back up `.env` and the existing SQLite database first. Stop the bot; replace source files; keep your original `.env`, database, and stock encryption key; run `start_windows.bat`.

New commands: `/wallet balance|adjust|history`, `/order create|status|view`, `/promo create|redeem`, `/giveaway start|enter`, `/restock alert`, `/subscription info|expiring`, `/security join-alerts`, `/invite stats|refresh`, `/backup create`.

**Notes:** Credits are internal, non-cash store points, not payment processing. Coupons are limited by total uses, not one redemption per person. Orders are manually recorded; changing their status does not charge cards or deliver stock. Giveaway winner selection is automatic every five minutes. Restock checks run every five minutes. Invite tracking is best-effort, starts when the bot is online, and requires Manage Server. Premium expiry display uses the existing licenses table; premium-role removal remains governed by existing bot logic. Backups export the SQLite database (including sensitive account inventory) privately to the configured owner: store securely and keep the encryption key separately. Do not post backups publicly. Join-spike detection sends warnings, not bans. Existing generator, tickets, reviews, welcome and RestoreCord remain untouched.

**Testing:** Syntax validation completed. Live Discord and database integration tests were not performed. Test on a spare server before production.
