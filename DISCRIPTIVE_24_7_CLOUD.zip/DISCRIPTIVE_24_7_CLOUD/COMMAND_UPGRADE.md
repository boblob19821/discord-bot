# Discriptive Command Upgrade

Adds:
- /wallet leaderboard (staff)
- /order mine, /order queue (staff queue)
- /giveaway list, /giveaway cancel (staff cancel)
- /invite leaderboard
- /security overview (staff)
- Fixes order-create ID lookup on databases that don't preserve last_insert_rowid between calls.

All previous command groups are retained. Does not reset or migrate stock.
Keep your existing .env, data folder, and STOCK_ENCRYPTION_KEY.

To install: stop bot, back up .env and data, replace source files, restart.
The bot syncs commands at startup. If old commands remain, use /admin sync.

Limitations: this is an incremental reliability and command expansion, not a guarantee of production readiness. Test in a private server before selling anything.
