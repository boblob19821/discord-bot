"""Shared validation, duration parsing, and safe formatting utilities."""
from __future__ import annotations

import re
import secrets
from datetime import datetime, timedelta, timezone
from dateutil.relativedelta import relativedelta

UTC = timezone.utc
CATEGORY_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{1,31}$")
PART_RE = re.compile(r"(\d+)(mo|y|w|d|h|m)", re.IGNORECASE)
KEY_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

class BotError(Exception):
    """A safe, human-readable error for slash commands."""


def now() -> datetime:
    return datetime.now(UTC)


def stamp(dt: datetime) -> int:
    return int(dt.timestamp())


def utc_from_stamp(value: int) -> datetime:
    return datetime.fromtimestamp(value, tz=UTC)


def validate_category(raw: str) -> str:
    name = raw.lower().strip()
    if not CATEGORY_RE.fullmatch(name):
        raise BotError("Category must be 2–32 characters: lowercase letters, numbers, - or _.")
    return name


def parse_duration(raw: str, start: datetime | None = None) -> datetime:
    """Accept 1h, 7d, 2w, 6mo, 1y, or combinations like 1y2mo3d4h30m.

    Years and months are calendar based, not fixed-day approximations.
    """
    val = re.sub(r"\s+", "", raw.lower())
    pieces = list(PART_RE.finditer(val))
    if not pieces or "".join(p.group(0) for p in pieces) != val:
        raise BotError("Invalid duration. Try `12h`, `7d`, `2w`, `6mo`, `1y`, or `1y2mo3d`.")
    values = {u: 0 for u in ("y", "mo", "w", "d", "h", "m")}
    for piece in pieces:
        count, unit = int(piece.group(1)), piece.group(2)
        if count < 1:
            raise BotError("Duration values must be greater than zero.")
        values[unit] += count
    if values["y"] > 10 or values["mo"] > 120 or values["w"] > 520 or values["d"] > 3650:
        raise BotError("Please choose a duration no longer than 10 years.")
    base = start or now()
    end = base + relativedelta(years=values["y"], months=values["mo"])
    end += timedelta(weeks=values["w"], days=values["d"], hours=values["h"], minutes=values["m"])
    if end <= base or end > base + relativedelta(years=10):
        raise BotError("Duration must be between one minute and ten years.")
    return end


def new_key() -> str:
    chars = "".join(secrets.choice(KEY_CHARS) for _ in range(20))
    return "YZVT-" + "-".join(chars[i:i+5] for i in range(0, 20, 5))


def unix_fmt(seconds: int | None) -> str:
    return f"<t:{seconds}:F> (<t:{seconds}:R>)" if seconds else "Not set"


def safe_snippet(value: str, limit: int = 500) -> str:
    """Avoid Markdown and mentions from user-supplied content in embeds."""
    cleaned = value.replace("`", "ˈ").replace("@", "＠")
    return cleaned[:limit] + ("…" if len(cleaned) > limit else "")
