"""Make a consistent, local SQLite snapshot for a hosting migration.
Does not decrypt credentials, print secrets or upload anything.
Stop your local bot first to avoid changes after the snapshot.
"""
from __future__ import annotations
import argparse
import sqlite3
from pathlib import Path

def main():
    parser=argparse.ArgumentParser(description="Export a SQLite snapshot for cloud migration")
    parser.add_argument('--source',default='data/yzvt.db')
    parser.add_argument('--output',default='discriptive_migration.db')
    args=parser.parse_args()
    source=Path(args.source)
    output=Path(args.output)
    if not source.is_file():
        raise SystemExit(f'Database not found: {source}. Did you run the original bot from this folder?')
    if source.resolve()==output.resolve():
        raise SystemExit('Source and output must be different files.')
    if output.exists():
        raise SystemExit(f'Refusing to overwrite {output}; choose a new --output path.')
    with sqlite3.connect(f'file:{source.resolve().as_posix()}?mode=ro',uri=True) as src:
        with sqlite3.connect(output) as dest:
            src.backup(dest)
            result=dest.execute('PRAGMA integrity_check').fetchone()[0]
            if result != 'ok':
                raise SystemExit(f'Backup integrity check failed: {result}')
    print(f'Private database snapshot saved to {output}.')
    print('Do NOT commit or share it. Upload it only to your own cloud volume.')
    print('Keep the original STOCK_ENCRYPTION_KEY; otherwise encrypted stock becomes unreadable.')
if __name__=='__main__': main()
