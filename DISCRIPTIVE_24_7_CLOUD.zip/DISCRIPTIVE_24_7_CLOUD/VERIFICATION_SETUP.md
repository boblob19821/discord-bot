# Verification is handled by RestoreCord

This package does **not** create verification roles, buttons, or channel locks.

1. Set up RestoreCord separately according to its official setup instructions.
2. Keep RestoreCord's entry/verification channel visible to visitors.
3. Give RestoreCord, not this bot, responsibility for Verified-role assignments.
4. Configure the welcome channel using `/welcome setup`.
5. If an **older** version of this bot previously ran `/verify lock`, those channel permission overrides remain until removed manually (or with the old `/verify unlock` before upgrading). This upgrade does not change channel permissions.

Do not give a Verified role using `/welcome setup auto_role`, as that would bypass RestoreCord.
