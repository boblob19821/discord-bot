"""Local storage integration tests. Runs when aiosqlite is installed."""
import asyncio
import hashlib
import importlib.util
import tempfile
import unittest
from datetime import timedelta

from cryptography.fernet import Fernet
from core import BotError, now, stamp


@unittest.skipUnless(importlib.util.find_spec('aiosqlite'), 'Install requirements to run SQLite tests')
class StorageTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        from storage import Database
        self.tmp=tempfile.TemporaryDirectory()
        self.db=Database(self.tmp.name+'/tests.db',Fernet.generate_key().decode())
        await self.db.start()
        await self.db.exec("INSERT INTO categories(guild_id,name,tier,cooldown_sec) VALUES(?,?,?,?)",
                           (123,'free-codes','free',0))
        await self.db.exec("INSERT INTO categories(guild_id,name,tier,cooldown_sec) VALUES(?,?,?,?)",
                           (123,'paid-codes','paid',0))
        self.free=(await self.db.one("SELECT id FROM categories WHERE guild_id=? AND name=?",(123,'free-codes')))['id']
        self.paid=(await self.db.one("SELECT id FROM categories WHERE guild_id=? AND name=?",(123,'paid-codes')))['id']

    async def asyncTearDown(self):
        await self.db.close()
        self.tmp.cleanup()

    async def test_encrypted_atomic_claim_and_duplicates(self):
        inserted, duplicates=await self.db.add_stock(123,self.free,1,['MY-OWN-CODE','MY-OWN-CODE'])
        self.assertEqual((inserted,duplicates),(1,1))
        row=await self.db.one("SELECT cipher FROM stock WHERE category_id=?",(self.free,))
        self.assertNotIn('MY-OWN-CODE',row['cipher'])
        results=await asyncio.gather(self.db.claim_stock(123,'free-codes',20,False),
                                     self.db.claim_stock(123,'free-codes',21,False),return_exceptions=True)
        self.assertEqual(sum(isinstance(x,tuple) for x in results),1)
        self.assertEqual(sum(isinstance(x,BotError) for x in results),1)
        good=next(x for x in results if isinstance(x,tuple))
        self.assertEqual(good[0],'MY-OWN-CODE')

    async def test_license_redeem_single_use(self):
        code='YZVT-TESTKEY-PRIVATE'
        digest=hashlib.sha256(code.encode()).hexdigest()
        await self.db.exec("INSERT INTO access_keys(code_hash,guild_id,duration,created_by,created_at) "
                           "VALUES(?,?,?,?,?)",(digest,123,'2w3d',1,stamp(now())))
        expiry=await self.db.redeem(123,5,code)
        self.assertGreaterEqual(expiry,stamp(now()+timedelta(days=16)))
        with self.assertRaises(BotError):await self.db.redeem(123,6,code)
        await self.db.add_stock(123,self.paid,1,['PREMIUM-TEST-CODE'])
        claim=await self.db.claim_stock(123,'paid-codes',5,False)
        self.assertEqual(claim[0],'PREMIUM-TEST-CODE')

    async def test_premium_access_blocked(self):
        await self.db.add_stock(123,self.paid,1,['PRIVATE-CODE'])
        with self.assertRaises(BotError):await self.db.claim_stock(123,'paid-codes',77,False)

    async def test_setting_persistence_and_category_creation(self):
        await self.db.exec("INSERT INTO bot_settings(name,value) VALUES (?,?)",("presence",'{"text":"Testing /gen", "type":"playing", "state":"online"}'))
        row = await self.db.one("SELECT value FROM bot_settings WHERE name='presence'")
        self.assertIn("Testing /gen",row['value'])
        await self.db.set_setting(123,'audit_channel_id',789)
        self.assertEqual((await self.db.setting(123))['audit_channel_id'],789)
        await self.db.exec("INSERT INTO categories(guild_id,name,tier,cooldown_sec) VALUES(?,?,?,?)", (123,'created-by-test','free',3600))
        row=await self.db.one("SELECT * FROM categories WHERE guild_id=? AND name=?", (123,'created-by-test'))
        self.assertEqual(row['cooldown_sec'],3600)
        self.assertEqual(row['tier'],'free')

    async def test_key_redeem_deadline_and_lifetime(self):
        from datetime import timedelta
        code='YZVT-EXPIRED-KEY'
        hashed=hashlib.sha256(code.encode()).hexdigest()
        await self.db.exec("INSERT INTO access_keys(code_hash,guild_id,duration,created_by,created_at,redeem_before) VALUES(?,?,?,?,?,?)", (hashed,123,'1h',1,stamp(now()),stamp(now()-timedelta(days=1))))
        with self.assertRaises(BotError):
            await self.db.redeem(123,5,code)

    async def test_claim_cooldown_and_server_isolation(self):
        await self.db.exec("UPDATE categories SET cooldown_sec=3600 WHERE id=?",(self.free,))
        await self.db.add_stock(123,self.free,1,['TEST-A','TEST-B'])
        await self.db.claim_stock(123,'free-codes',200,False)
        with self.assertRaises(BotError):
            await self.db.claim_stock(123,'free-codes',200,False)
        with self.assertRaises(BotError):
            await self.db.claim_stock(999,'free-codes',200,False)
        remaining = await self.db.one("SELECT COUNT(*) AS n FROM stock WHERE category_id=?",(self.free,))
        self.assertEqual(remaining['n'],1)
