from datetime import datetime,timezone
import unittest
from core import BotError,new_key,validate_category,parse_duration

class CoreTests(unittest.TestCase):
    def test_dates(self):
        start=datetime(2026,1,31,tzinfo=timezone.utc)
        self.assertEqual(parse_duration('1mo',start).month,2)
        self.assertEqual(parse_duration('1mo',start).day,28)
        self.assertEqual(parse_duration('2w3d4h',start).day,17)
        with self.assertRaises(BotError):parse_duration('never',start)
        with self.assertRaises(BotError):parse_duration('15y',start)
        with self.assertRaises(BotError):parse_duration('0d',start)
    def test_names(self):
        self.assertEqual(validate_category('  Game_Codes '),'game_codes')
        with self.assertRaises(BotError):validate_category('bad category')
    def test_keys(self):
        keys={new_key() for _ in range(1000)}
        self.assertEqual(len(keys),1000)
        self.assertTrue(all(len(code)==28 and code.startswith('YZVT-') for code in keys))

if __name__=='__main__':unittest.main()
