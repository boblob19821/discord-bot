"""Offline command registration smoke test (does not connect to Discord)."""
import importlib.util
import unittest
from cryptography.fernet import Fernet

HAS_DEPS = all(importlib.util.find_spec(name) for name in ("discord","aiosqlite"))


@unittest.skipUnless(HAS_DEPS,"Install requirements to check discord.py command registration")
class CommandRegistrationTests(unittest.IsolatedAsyncioTestCase):
    async def test_every_command_registers_once(self):
        from bot import YZVT
        bot = YZVT("not-a-real-token", Fernet.generate_key().decode(), "unused.db", 1234567890, 0)
        try:
            for ext in ("cogs.inventory","cogs.premium","cogs.support","cogs.reviews", "cogs.welcome","cogs.admin","cogs.status"):
                await bot.load_extension(ext)
            groups = {command.name: command for command in bot.tree.get_commands()}
            self.assertEqual(len(groups), 12)
            self.assertEqual(set(groups), {"gen","add","category","stock","key","ticket","vouch","welcome","admin","status","help","ping"})
            required = {
                "add":{"category","catagory","stock"},
                "gen":{"free","paid","categories","history"},
                "status":{"set","clear","show"},
                "admin":{"sync","dashboard","settings","paid_role","remove_paid_role","audit_channel","reset_cooldown","audit","prune"},
                "ticket":{"open","panel","setup","close","claim","add_user","remove_user","rename","transcript","stats"},
                "key":{"create","redeem","status","grant","revoke","revoke_member","overview"},
            }
            for group, subnames in required.items():
                got={cmd.name for cmd in groups[group].commands}
                self.assertTrue(subnames.issubset(got), f"{group}: missing {subnames-got}")
                self.assertEqual(len(got),len(groups[group].commands),f"Duplicate command under {group}")
        finally:
            await bot.close()
