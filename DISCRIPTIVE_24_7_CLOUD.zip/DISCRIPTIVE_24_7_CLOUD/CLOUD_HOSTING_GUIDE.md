# Discriptive — run your bot when your PC is off

This is your existing bot with cloud hosting files added; it is **not an already-hosted service**. No Discord token or existing database is included. You configure and deploy it to a cloud account you control.

## Recommended: Railway persistent service

1. **Back up your original bot** including its `data/` directory and `.env`. Stop it with Ctrl+C. Do not regenerate the stock encryption key.
2. Extract `DISCRIPTIVE_24_7_CLOUD.zip`. Create a **private** GitHub repository and upload the extracted project files, including the root `Dockerfile`, `requirements.txt`, `bot.py`, `cogs/`, `railway.json`, etc. **Never** upload `.env`, token, real stock, or any `.db` file to GitHub. `.gitignore` and `.dockerignore` help but verify the uploaded files yourself.
3. In [Railway](https://railway.com/), create a project and deploy **from that GitHub repository**. It will use the included `Dockerfile` automatically. Choose a persistent service that does not sleep; check your plan's runtime budget.
4. On the Railway service **Variables** tab, create these variables with your own private values:
   - `DISCORD_TOKEN` = the Discord bot token for your existing Discriptive application (not a new bot token unless you intend to switch applications)
   - `STOCK_ENCRYPTION_KEY` = **exactly the same value** as your old `.env`; if you have an existing database, do not generate a new key
   - `TEST_GUILD_ID` = your Discord server's numeric ID (or `0` for global sync)
   - `OWNER_ID` = your user ID (optional; `0` disables the explicit owner setting)
   - `DATABASE_PATH` = `/app/data/yzvt.db`
5. Attach a **Railway Volume** to the bot service with mount path **`/app/data`**. This is essential: the bot uses SQLite, and without a volume your categories, stock, keys, wallets and orders could be erased on redeploy/restart. Use one replica only; SQLite is not designed for multiple bot replicas sharing one database file.
6. **To preserve existing accounts/stock/keys/orders**: before allowing the new cloud instance to generate stock, export the original database from your stopped PC bot with:

   ```powershell
   py backup_for_cloud.py --source "C:\path\to\YOUR_OLD_BOT\data\yzvt.db" --output discriptive_migration.db
   ```

   You may need to use `python` instead of `py`. Do this outside a public/shared directory. Install Railway CLI according to Railway's documentation; authenticate and select your new project/service. **Stop the Railway bot deployment while uploading to avoid replacing an open database.** Upload the resulting private DB file to the new volume; for a volume mounted at `/app/data`, the *volume-relative path* is `/yzvt.db`:

   ```sh
   railway volume files upload ./discriptive_migration.db /yzvt.db
   ```

   The CLI may ask which volume to use; follow its prompts. After uploading, start/redeploy the service. **Do not** publish the migration file to GitHub. Preserve your original database as a backup. If you have already run the cloud service and created new stock there, reconcile the two databases first: uploading will replace the cloud copy.
7. Open the service **Deploy Logs**. Look for `Online as ...` and `Refreshed ... slash groups/commands`. Test `/gen categories`, `/wallet balance` and `/admin dashboard` in your Discord server. The bot does **not** listen for HTTP requests and does **not** need a public domain, port or website health check.
8. Finally close CMD on your PC or switch off your computer. **Don't run the local bot using the same Discord token at the same time as the cloud bot**. The cloud instance should be the only running instance.

### Updates and recovery

- Push changed bot code to your private repository; Railway will rebuild the worker. `railway.json` requests restarts on failures, but **no host guarantees 100% uptime** and some plans limit restarts.
- **Keep both** a private DB backup and your `STOCK_ENCRYPTION_KEY`. Restore them together. Keep secrets off screenshots and public repos.
- Cloud volumes keep files through restarts and redeploys, but are **not a replacement for backups**.
- After moving over, slash commands should resync each time the bot starts. One guild configured via `TEST_GUILD_ID` makes testing faster.
- Basic verification is handled by RestoreCord separately; no RestoreCord hosting is included here.

## Alternative: a VPS with Docker Compose

On your own Linux VPS with Docker installed, keep a private `.env` in the project folder and run:

```sh
docker compose up -d --build
docker compose logs -f discriptive
```

The included `compose.yaml` uses `restart: unless-stopped` and a named Docker volume for SQLite. To preserve existing data on a VPS, restore your stopped bot's DB into that named volume before starting the bot. This is an **alternative**, not something you need for Railway.

## Which hosting should I choose?

- Railway: simpler setup; a paid plan is usually more dependable for a continuously running bot. Check current plans/costs at the provider.
- A VPS: more configuration, but full control over process and storage.
- A PC-only launcher: **cannot** stay running after the PC turns off, regardless of the bot code.

If you see `DISCORD_TOKEN missing`, configure the Railway Variables tab; do not put secrets in source code. If you see `no such table`, verify `DATABASE_PATH` and the volume location. If inventory vanishes after redeployment, check the service's `/app/data` volume and the uploaded database. If commands duplicate, make sure only one process is running and check `TEST_GUILD_ID`.
