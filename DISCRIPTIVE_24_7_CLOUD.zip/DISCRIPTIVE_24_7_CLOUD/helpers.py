"""Discord-specific helpers and permission gates."""
import io
import discord
from discord import app_commands
from core import BotError, safe_snippet


def is_manager(interaction: discord.Interaction) -> bool:
    user = interaction.user
    return bool(interaction.guild and isinstance(user, discord.Member)
                and (user.guild_permissions.manage_guild or user.id == interaction.client.owner_id_config))


def manager_only():
    async def predicate(interaction: discord.Interaction) -> bool:
        if not is_manager(interaction):
            raise BotError("You need **Manage Server** permission for this command.")
        return True
    return app_commands.check(predicate)


async def ensure_deferred(interaction: discord.Interaction):
    """Defer slash or modal/button actions, if a response has not begun."""
    if not interaction.response.is_done():
        await interaction.response.defer(ephemeral=True, thinking=True)


async def answer(interaction: discord.Interaction, content=None, **kwargs):
    kwargs.setdefault('ephemeral', True)
    if interaction.response.is_done():
        return await interaction.followup.send(content, **kwargs)
    return await interaction.response.send_message(content, **kwargs)


async def attachment_reply(interaction: discord.Interaction, title: str, payload: str, filename="output.txt"):
    if len(payload) <= 1600:
        return await answer(interaction, f"**{title}**\n```\n{payload}\n```")
    f = discord.File(io.BytesIO(payload.encode('utf-8')), filename=filename)
    return await answer(interaction, f"**{title}** — attached private text file.", file=f)


def text_channel(guild: discord.Guild, channel_id: int | None):
    ch = guild.get_channel(channel_id) if channel_id else None
    return ch if isinstance(ch, discord.TextChannel) else None


def safe_embed(title: str, description: str = "", color=discord.Color.blurple()):
    return discord.Embed(title=title, description=safe_snippet(description, 3500), color=color)


async def audit(bot, guild: discord.Guild, actor_id: int, action: str, detail: str = ""):
    await bot.db.audit(guild.id, actor_id, action, detail)
    row = await bot.db.setting(guild.id)
    channel = text_channel(guild, row['audit_channel_id'])
    if channel:
        try:
            embed = safe_embed(f"Audit • {action}", f"Actor: <@{actor_id}>\n{detail}")
            await channel.send(embed=embed, allowed_mentions=discord.AllowedMentions.none())
        except (discord.HTTPException, discord.Forbidden):
            pass
