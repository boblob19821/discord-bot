"""SQLite storage. Each database operation is serialized for atomic stock claims."""
from __future__ import annotations

import asyncio
import hashlib
import hmac
from pathlib import Path
from datetime import datetime, timezone

import aiosqlite
from cryptography.fernet import Fernet
from core import BotError, now, parse_duration, stamp

SCHEMA = """
CREATE TABLE IF NOT EXISTS bot_settings (
 name TEXT PRIMARY KEY, value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS guilds (
 guild_id INTEGER PRIMARY KEY,
 paid_role_id INTEGER, ticket_category_id INTEGER, ticket_log_id INTEGER,
 staff_role_id INTEGER, vouch_channel_id INTEGER, welcome_channel_id INTEGER,
 welcome_text TEXT NOT NULL DEFAULT 'Welcome {mention} to {server}! You are member #{member_count}.',
 welcome_role_id INTEGER, welcome_enabled INTEGER NOT NULL DEFAULT 0,
 audit_channel_id INTEGER
);
CREATE TABLE IF NOT EXISTS welcome_profiles (
 guild_id INTEGER PRIMARY KEY,
 preset TEXT NOT NULL DEFAULT 'marketplace',
 theme TEXT NOT NULL DEFAULT 'midnight',
 ping_template TEXT,
 title_template TEXT,
 description_template TEXT,
 footer_template TEXT,
 brand TEXT NOT NULL DEFAULT 'DISCRIPTIVE',
 color TEXT NOT NULL DEFAULT '#27B7FF',
 show_card INTEGER NOT NULL DEFAULT 1,
 verify_button INTEGER NOT NULL DEFAULT 0,
 mention_enabled INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS categories (
 id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER NOT NULL,
 name TEXT NOT NULL COLLATE NOCASE, tier TEXT NOT NULL CHECK (tier IN ('free','paid')),
 cooldown_sec INTEGER NOT NULL DEFAULT 3600,
 UNIQUE(guild_id,name)
);
CREATE TABLE IF NOT EXISTS stock (
 id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER NOT NULL,
 category_id INTEGER NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
 cipher TEXT NOT NULL, digest TEXT NOT NULL, added_by INTEGER NOT NULL, created_at INTEGER NOT NULL,
 UNIQUE(category_id,digest)
);
CREATE INDEX IF NOT EXISTS idx_stock_category ON stock(category_id,id);
CREATE TABLE IF NOT EXISTS claims (
 guild_id INTEGER NOT NULL, category_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
 claimed_at INTEGER NOT NULL, PRIMARY KEY(guild_id,category_id,user_id)
);
CREATE TABLE IF NOT EXISTS generation_history (
 id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER NOT NULL, category_id INTEGER NOT NULL,
 user_id INTEGER NOT NULL, generated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS licenses (
 guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
 expires_at INTEGER NOT NULL, PRIMARY KEY(guild_id,user_id)
);
CREATE TABLE IF NOT EXISTS access_keys (
 code_hash TEXT PRIMARY KEY, guild_id INTEGER NOT NULL, duration TEXT NOT NULL,
 created_by INTEGER NOT NULL, created_at INTEGER NOT NULL, redeem_before INTEGER,
 used_by INTEGER, used_at INTEGER, revoked INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_keys_guild ON access_keys(guild_id,used_by,revoked);
CREATE TABLE IF NOT EXISTS tickets (
 id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
 channel_id INTEGER, subject TEXT NOT NULL, details TEXT NOT NULL, status TEXT NOT NULL,
 claimed_by INTEGER, opened_at INTEGER NOT NULL, closed_at INTEGER, closed_by INTEGER, close_reason TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_one_open_ticket ON tickets(guild_id,user_id)
 WHERE status IN ('pending','open');
CREATE INDEX IF NOT EXISTS idx_ticket_channel ON tickets(channel_id);
CREATE TABLE IF NOT EXISTS vouches (
 id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER NOT NULL,
 ticket_id INTEGER NOT NULL UNIQUE, user_id INTEGER NOT NULL,
 rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5), comment TEXT NOT NULL,
 posted_at INTEGER NOT NULL, message_id INTEGER
);
CREATE TABLE IF NOT EXISTS audit (
 id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER NOT NULL,
 actor_id INTEGER NOT NULL, action TEXT NOT NULL, detail TEXT NOT NULL, created_at INTEGER NOT NULL
);
"""


class Database:
    def __init__(self, path: str, encryption_key: str):
        self.path = Path(path)
        self.cipher = Fernet(encryption_key.encode())
        self.hmac_key = hashlib.sha256(encryption_key.encode()).digest()
        self.lock = asyncio.Lock()
        self.conn: aiosqlite.Connection | None = None

    async def start(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = await aiosqlite.connect(self.path)
        self.conn.row_factory = aiosqlite.Row
        await self.conn.execute("PRAGMA foreign_keys=ON")
        await self.conn.execute("PRAGMA journal_mode=WAL")
        await self.conn.execute("PRAGMA busy_timeout=5000")
        await self.conn.executescript(SCHEMA)
        await self.conn.commit()

    async def close(self):
        if self.conn:
            await self.conn.close()

    async def one(self, query: str, params: tuple = ()):
        async with self.lock:
            async with self.conn.execute(query, params) as cur:
                return await cur.fetchone()

    async def all(self, query: str, params: tuple = ()):
        async with self.lock:
            async with self.conn.execute(query, params) as cur:
                return await cur.fetchall()

    async def exec(self, query: str, params: tuple = ()): 
        async with self.lock:
            cur = await self.conn.execute(query, params)
            await self.conn.commit()
            return cur.rowcount

    async def setting(self, guild_id: int):
        await self.exec("INSERT OR IGNORE INTO guilds(guild_id) VALUES (?)", (guild_id,))
        return await self.one("SELECT * FROM guilds WHERE guild_id=?", (guild_id,))

    async def set_setting(self, guild_id: int, field: str, value):
        columns = {'paid_role_id','ticket_category_id','ticket_log_id','staff_role_id',
                   'vouch_channel_id','welcome_channel_id','welcome_text',
                   'welcome_role_id','welcome_enabled','audit_channel_id'}
        if field not in columns:
            raise ValueError("Unsupported setting")
        await self.setting(guild_id)
        await self.exec(f"UPDATE guilds SET {field}=? WHERE guild_id=?", (value, guild_id))

    async def welcome_profile(self, guild_id: int):
        await self.exec("INSERT OR IGNORE INTO welcome_profiles(guild_id) VALUES(?)", (guild_id,))
        return await self.one("SELECT * FROM welcome_profiles WHERE guild_id=?", (guild_id,))

    async def set_welcome_profile(self, guild_id: int, **fields):
        allowed = {'preset', 'theme', 'ping_template', 'title_template', 'description_template',
                   'footer_template', 'brand', 'color', 'show_card', 'verify_button',
                   'mention_enabled'}
        if not fields or set(fields) - allowed:
            raise ValueError('Unsupported welcome profile field')
        await self.welcome_profile(guild_id)
        updates = ', '.join(f'{field}=?' for field in fields)
        await self.exec(f'UPDATE welcome_profiles SET {updates} WHERE guild_id=?',
                        (*fields.values(), guild_id))

    async def audit(self, guild_id: int, actor_id: int, action: str, detail: str = ""):
        await self.exec("INSERT INTO audit(guild_id,actor_id,action,detail,created_at) VALUES(?,?,?,?,?)",
                        (guild_id,actor_id,action,detail[:250],stamp(now())))

    def digest(self, category_id: int, value: str) -> str:
        return hmac.new(self.hmac_key, f"{category_id}:".encode()+value.encode(), hashlib.sha256).hexdigest()

    async def add_stock(self, guild_id: int, category_id: int, actor_id: int, lines: list[str]):
        clean_lines = [x.strip() for x in lines if x.strip()]
        unique = list(dict.fromkeys(clean_lines))
        if not unique:
            raise BotError("No non-empty stock lines were provided.")
        if len(unique) > 10000:
            raise BotError("Max 10,000 entries per import.")
        if any(len(s) > 16000 for s in unique):
            raise BotError("One of the entries is too long (16,000 character limit).")
        now_ts = stamp(now())
        async with self.lock:
            try:
                await self.conn.execute("BEGIN IMMEDIATE")
                count = 0
                for text in unique:
                    cipher = self.cipher.encrypt(text.encode()).decode()
                    dig = self.digest(category_id, text)
                    cur = await self.conn.execute(
                        "INSERT OR IGNORE INTO stock(guild_id,category_id,cipher,digest,added_by,created_at) "
                        "VALUES(?,?,?,?,?,?)",(guild_id,category_id,cipher,dig,actor_id,now_ts))
                    count += cur.rowcount
                await self.conn.commit()
                return count, len(clean_lines)-count
            except Exception:
                await self.conn.rollback()
                raise

    async def claim_stock(self, guild_id: int, name: str, user_id: int, has_paid_role: bool):
        """One transaction checks inventory, paid access and cooldown, then consumes a single entry."""
        ts = stamp(now())
        async with self.lock:
            try:
                await self.conn.execute("BEGIN IMMEDIATE")
                async def query(sql, params):
                    async with self.conn.execute(sql,params) as c:
                        return await c.fetchone()
                category = await query("SELECT * FROM categories WHERE guild_id=? AND name=? COLLATE NOCASE", (guild_id,name))
                if not category:
                    raise BotError("Category not found. Use `/gen categories` to view what's available.")
                if category['tier'] == 'paid' and not has_paid_role:
                    license_row = await query("SELECT expires_at FROM licenses WHERE guild_id=? AND user_id=?", (guild_id,user_id))
                    if not license_row or license_row['expires_at'] <= ts:
                        raise BotError("Premium access required. Redeem a valid key with `/key redeem`.")
                prev = await query("SELECT claimed_at FROM claims WHERE guild_id=? AND category_id=? AND user_id=?",
                                   (guild_id,category['id'],user_id))
                if prev and ts < prev['claimed_at']+category['cooldown_sec']:
                    remaining = prev['claimed_at'] + category['cooldown_sec']
                    raise BotError(f"Cooldown active. Try again <t:{remaining}:R>.")
                entry = await query("SELECT id,cipher FROM stock WHERE category_id=? ORDER BY id LIMIT 1", (category['id'],))
                if not entry:
                    raise BotError("This category is currently out of stock.")
                plaintext = self.cipher.decrypt(entry['cipher'].encode()).decode()
                await self.conn.execute("DELETE FROM stock WHERE id=?", (entry['id'],))
                await self.conn.execute("INSERT INTO claims(guild_id,category_id,user_id,claimed_at) VALUES (?,?,?,?) "
                                        "ON CONFLICT(guild_id,category_id,user_id) DO UPDATE SET claimed_at=excluded.claimed_at",
                                        (guild_id,category['id'],user_id,ts))
                await self.conn.execute("INSERT INTO generation_history(guild_id,category_id,user_id,generated_at) VALUES(?,?,?,?)",
                                        (guild_id,category['id'],user_id,ts))
                await self.conn.commit()
                return plaintext, category
            except Exception:
                await self.conn.rollback()
                raise

    async def redeem(self, guild_id: int, user_id: int, plaintext_code: str):
        code_hash = hashlib.sha256(plaintext_code.upper().strip().encode()).hexdigest()
        ts = stamp(now())
        async with self.lock:
            try:
                await self.conn.execute("BEGIN IMMEDIATE")
                async def query(sql, params):
                    async with self.conn.execute(sql,params) as c: return await c.fetchone()
                row = await query("SELECT * FROM access_keys WHERE code_hash=? AND guild_id=?",(code_hash,guild_id))
                if not row or row['revoked'] or row['used_by'] is not None:
                    raise BotError("This key is invalid, revoked, or already redeemed.")
                if row['redeem_before'] and row['redeem_before'] <= ts:
                    raise BotError("This key has expired before redemption.")
                prior = await query("SELECT expires_at FROM licenses WHERE guild_id=? AND user_id=?",(guild_id,user_id))
                start = max(ts, prior['expires_at'] if prior else 0)
                expiry = stamp(parse_duration(row['duration'], datetime.fromtimestamp(start, tz=timezone.utc)))
                await self.conn.execute("INSERT INTO licenses(guild_id,user_id,expires_at) VALUES(?,?,?) "
                                        "ON CONFLICT(guild_id,user_id) DO UPDATE SET expires_at=excluded.expires_at",
                                        (guild_id,user_id,expiry))
                await self.conn.execute("UPDATE access_keys SET used_by=?, used_at=? WHERE code_hash=?",(user_id,ts,code_hash))
                await self.conn.commit()
                return expiry
            except Exception:
                await self.conn.rollback()
                raise
