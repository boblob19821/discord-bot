# Discriptive Welcomer Pro (RestoreCord edition)

A branded, tagged welcome message that resembles popular welcome bots. **No Verify buttons or other verification features.** RestoreCord handles verification separately.

1. Back up your bot's `.env` and database / `data` folder, stop the bot, then replace the source files with these.
2. Run `install_windows.bat` if Pillow or dependencies are missing; then run `start_windows.bat`.
3. Enable **Server Members Intent** for your Discord application in the Developer Portal (Bot tab).
4. Run `/welcome setup channel:#welcome` (leave `auto_role` empty if RestoreCord handles roles).
5. Run `/welcome template preset:Marketplace`, `/welcome brand name:Discriptive`, then `/welcome test` for a private preview.
6. Customise `/welcome message`, `/welcome ping`, `/welcome headline`, `/welcome theme`, `/welcome colour`, `/welcome card`, and `/welcome tag`.
7. Run `/welcome status` to see your configuration. The real incoming member gets tagged; previews do **not** ping anyone.

Available template tokens: `{mention}`, `{user}`, `{username}`, `{server}`, `{member_count}`, `{rules_channel}`, `{shop_channel}`, `{generator_channel}`.

The bot synchronises slash commands on restart using TEST_GUILD_ID. Old `/welcome button` and `/verify` commands from this bot are removed during sync. RestoreCord is a separate app and is not modified.

**Note:** Updating the bot will not remove older `/verify lock` permission overwrites if they were previously applied. Check channel access in your test server.
