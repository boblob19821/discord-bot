from cryptography.fernet import Fernet
print('STOCK_ENCRYPTION_KEY=' + Fernet.generate_key().decode())
print('Save this value securely. Losing it makes your encrypted stock unrecoverable.')
