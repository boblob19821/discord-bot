# DISCRIPTIVE — 24/7 CLOUD READY

**First-time hosting? Read [CLOUD_HOSTING_GUIDE.md](CLOUD_HOSTING_GUIDE.md).**

This package retains the existing Discriptive commands, generator, welcome system, RestoreCord-compatible setup, tickets, stock, and customer features. It adds Railway/Docker deployment support without embedding credentials. The bot is **not already hosted**.

---

# YZVT Generator Bot | Discord Slash Edition

A fully source-available, single-process Discord bot using **slash commands only**. It handles encrypted inventory you own / are authorised to share, free and premium generation, expiring key subscriptions, support tickets, verified support feedback, welcome embeds, permissions and administrative statistics.

**Status:** A complete, structured starter project. Core parsing, syntax, and offline checks have been run where dependencies are available, but live Discord API behaviour **has not been tested with a real token**. Make a private test server before deploying publicly. No hosting service, payment processor, customer account supplier or preloaded stock is included.

## Features at a glance

| System | Included |
| --- | --- |
| Free/paid generator | `/gen free`, `/gen paid`, `/gen categories`, `/gen history`, private result delivery, custom per-category cooldowns, atomic claim, stock counters |
| Product categories | `/add category` **and** `/add catagory` spelling alias, `/category edit`, `/category rename`, `/category delete` |
| Inventory | `/add stock` supports lines or bulk `.txt` files, duplicates rejected, Fernet encryption at rest, `/stock list`, `/stock export`, `/stock clear` |
| Premium keys | `/key create`, `/key redeem`, `/key status`, `/key grant`, `/key revoke`, `/key revoke_member`, `/key overview` |
| Custom subscription duration | `1h`, `12h`, `2d`, `2w`, `6mo`, `1y`, or combined `1y2mo5d12h30m`; membership starts **when the key is redeemed**; extends existing unexpired time |
| Key controls | 1–50 keys at a time, securely random and single use, SHA-256 hashed storage (plain key only shown at creation), optional redeem-by deadline |
| Tickets | `/ticket setup`, `/ticket panel`, `/ticket open`, `/ticket close`, `/ticket claim`, `/ticket add_user`, `/ticket remove_user`, `/ticket rename`, `/ticket transcript`, `/ticket stats` |
| Tickets UI | Persistent Open Ticket, Claim, Close buttons survive bot restart; one active ticket per member; private channels; staff role; transcript attachment sent to a staff-only log |
| Verified vouches | `/vouch submit`, `/vouch recent`, `/vouch stats`, `/vouch set_channel`, `/vouch lookup`, `/vouch remove`; one review per **own completed ticket**, not arbitrary manufactured ratings |
| Welcome | `/welcome setup`, `/welcome message`, `/welcome test`, `/welcome status`, `/welcome disable`; optional join role |
| Admin | `/admin dashboard`, `/admin settings`, `/admin paid_role`, `/admin remove_paid_role`, `/admin audit_channel`, `/admin reset_cooldown`, `/admin audit`, `/admin prune`, `/admin sync`, plus `/help`, `/ping` |
| Bot status | `/status set`, `/status show`, `/status clear`; custom, playing, watching, listening and competing activities, optional presence mode; saved over restarts |
| Command resilience | Every slash command is acknowledged privately before database/network operations; command definitions are reconciled with Discord at each startup |

## Upgrading an already running bot (keep your old data)

**Stop the running bot** (click the Command Prompt window and press Ctrl+C). Extract this new ZIP, then copy its **Python source files and cogs folder** over the matching files in your **existing** `YZVT_Generator_Bot` folder. Alternatively, unzip directly over the old folder and choose **Replace** for matching code files. **Do not delete the existing `.env`, `.venv/`, or `data/` folder.** The update ZIP contains none of these private files. Do not regenerate your Fernet key; encrypted stock relies on the existing one.

Run `start_windows.bat` again. New code automatically creates the extra status configuration table, without deleting existing data. **Slash commands sync automatically on EVERY startup** to the server in `TEST_GUILD_ID` (or globally if `TEST_GUILD_ID=0`), replacing renamed/deleted command definitions in that scope; `/admin sync` manually refreshes the same scope. This command refresh **does not clear your categories, cooldowns, keys or stock**. If you previously deployed globally and are now using a test guild, old global commands may still appear; change the sync scope deliberately rather than deleting unknown global registrations.

### New status commands

- `/status set text:Generating authorised codes activity:Watching presence:Online` — update and persist bot presence.
- `/status show` — view saved status configuration.
- `/status clear` — return to online with no activity.

Because bot presence is visible in every server the bot joins, only the `.env` `OWNER_ID` user can change it. If `OWNER_ID=0`, only the **owner of the selected Discord server** can change it. Set `OWNER_ID` to your own Discord user ID if you manage more than one server. The visible activity display depends on the Discord client and activity type.

### Troubleshooting "The application did not respond"

Every slash command now acknowledges its invocation immediately, then sends the private result once it is ready. If a command fails, you should receive an error message and a console traceback rather than a silent timeout. Errors **before** Discord receives an interaction or gateway connection errors can still occur; check the CMD window. Do not share screenshots of `.env`, tokens or decrypted stock.

## Requirements

- Windows 10/11 (also works on Linux with equivalent Python commands)
- Python 3.11 or 3.12, internet access for `pip` and Discord gateway
- A Discord bot created in the [Discord Developer Portal](https://discord.com/developers/applications)
- A test server in which you can administer channels, roles and commands

### 1. Make and invite your Discord bot

1. Open the Discord Developer Portal, create an **Application**, and open **Bot**.
2. Create or reset the **Bot Token**; copy it securely. Don't put it in messages, GitHub, screenshots or support requests.
3. Enable **Server Members Intent** (welcomer) and **Message Content Intent** (fuller ticket transcripts), if available for your application. Message Content Intent may require approval for large verified bots. The generator does not read ordinary messages or use a prefix command.
4. Under the app's **Installation** settings or OAuth2 URL Generator, enable **Guild Install** and the `bot` + `applications.commands` scopes.
5. Grant bot permissions: **View Channels**, **Send Messages**, **Read Message History**, **Embed Links**, **Attach Files**, **Manage Channels**, **Manage Roles** (only if assigning welcome roles). It will need to be able to manage channel overwrites and delete closed ticket channels.
6. Invite to your test server; move the bot's role **above** any welcome role it should assign. Restrict sensitive channels to authorised staff.

### 2. Easiest Windows setup (recommended)

1. Extract the full ZIP and open the **extracted** `YZVT_Generator_Bot` folder (do not run files from inside a compressed ZIP).
2. Double-click **`install_windows.bat`**. It creates the `.venv` automatically, installs `requirements.txt`, and creates a `.env` with a unique Fernet encryption key. **Do not paste the key into chat or share your `.env` file.**
3. Open Command Prompt in that folder or use the Run box and type `notepad .env`. Paste your own bot token in `DISCORD_TOKEN=` and set `TEST_GUILD_ID=` to your server ID. Save.
4. Double-click **`start_windows.bat`**. If you accidentally skip step 2, the launcher attempts the installer automatically.

The installer preserves existing `.env` secrets and stock. For Python, it tries Python 3.12, then 3.11, then 3.13. If none is installed, install Python 3.12, with the Python Launcher enabled. If `py -3.12 -m venv .venv` fails, run `py -0p` to view your installed versions.

**Note:** The correct pip command is `py -m pip install -r requirements.txt` (including `-r`), and it must be entered in **Command Prompt or PowerShell**, not a text editor. You do not need to run it yourself if you use the installer above.

### 3. Manual install locally (Windows PowerShell, optional)

Extract the ZIP, open PowerShell **inside** the extracted `YZVT_Generator_Bot` folder, and run:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
copy .env.example .env
.\.venv\Scripts\python.exe create_key.py
```

Edit `.env` using Notepad or VS Code. Replace `DISCORD_TOKEN`, `STOCK_ENCRYPTION_KEY` (with the full key printed above), `TEST_GUILD_ID` (your Discord server ID) and optionally `OWNER_ID`. Example:

```ini
DISCORD_TOKEN=your_actual_bot_token
STOCK_ENCRYPTION_KEY=your_generated_fernet_key
TEST_GUILD_ID=123456789012345678
OWNER_ID=123456789012345678
DATABASE_PATH=data/yzvt.db
```

**Keep the original Fernet key**: changing it makes previously stored stock unreadable. Save the `.env` file and the `data/` directory in a secure backup. The `.gitignore` deliberately excludes both.

Get the server ID: Discord Settings → Advanced → **Developer Mode** → right-click your server → **Copy Server ID**.

Run:

```powershell
.\.venv\Scripts\python.exe bot.py
```

Later, double-click `start_windows.bat`. The bot prints its connection status to the console. It must remain running to respond to commands; to have it online continuously, host it on a service that supports a long-running Python worker and persistent storage.

**Troubleshooting:** If `py -3.12` does not exist, install Python 3.12 or use `py -3.11` consistently. If commands do not appear, confirm `applications.commands` permissions and the matching `TEST_GUILD_ID`. With `TEST_GUILD_ID=0`, commands are registered globally instead and changes may take time to propagate.

### 4. Set up your server

Create a Discord **category** for support tickets, a **Support Team** role, a private transcript/log channel visible only to staff, a public vouch channel and a welcome channel. Then run the following **slash commands**, using Discord's suggested fields:

1. `/ticket setup` → select category, staff role, log channel.
2. `/ticket panel` → choose public support channel.
3. `/vouch set_channel` → choose vouch channel.
4. `/welcome setup` → choose welcome channel and optionally auto-role.
5. `/welcome message` → e.g. `Welcome {mention} to {server}! Member #{member_count}`.
6. `/admin audit_channel` → choose a private staff log channel.
7. `/add category` → e.g. name `demo-codes`, tier `free`, cooldown `60`.
8. `/add category` → e.g. name `premium-codes`, tier `paid`, cooldown `10`.
9. `/add stock` → category `demo-codes`, lines with **one legitimately owned code per line**, or a UTF-8 text attachment.
10. `/key create` → duration `2w`, quantity `3`, redeem_within_days `7`; the three private keys are shown once.

### 5. User flows

**Free:** User enters `/gen free category:demo-codes` → receives **one** available code in a private, ephemeral response. They cannot claim from that category again until its configured cooldown expires.

**Paid:** Manager creates keys with `/key create`, distributes them legitimately, and the recipient uses `/key redeem code:...`. The user sees expiry via `/key status`, and can run `/gen paid category:premium-codes`. A configured premium role is an alternative access method; premium keys do **not** automatically assign roles.

**Support:** User clicks the support panel or runs `/ticket open`. A private ticket is created; staff can claim it and close it. Closed tickets send up to 500 historical messages to the configured **staff-only** transcript channel. After closure, the original ticket owner may submit a review using `/vouch submit ticket_id:<id> rating:<1-5> comment:<text>`.

## Operations, security and limits

- **Authorised inventory only.** Add only account credentials, licence codes, vouchers or digital goods you own or are allowed to provide. No account scraping, account checking, credential acquisition or payment processing exists in this bot.
- **Private output:** Stock is exposed to users only in ephemeral interaction responses and to administrators via `/stock export`. The bot does not post item contents to audit channels or logs. Protect uploaded files and local database backups.
- **Encrypted stock:** Available inventory is encrypted in SQLite with Fernet. A keyed HMAC is used to reject duplicate entries. Historical generation records contain metadata only, not delivered secrets.
- **Keys:** A key is hashed in the database and cannot be recovered after the one-time creation response. Key access begins at redemption. `redeem_within_days` controls whether the **unused** key may be redeemed; the access duration is separate.
- **Cooldowns:** Evaluated transactionally with inventory consumption; claims on one process cannot double-issue the same item. Expired premium rights are checked dynamically, without requiring a background job.
- **Permissions:** Manage Server permission is checked inside all admin command callbacks, even if Discord command permissions were changed. The optional `OWNER_ID` is only an extra allowance on guilds where the owner is a member.
- **Reviews:** Reviews require your own closed ticket. They are not guaranteed proof of a transaction or product quality. Staff may remove abusive reviews and their removal is audited.
- **Ticket transcripts:** Up to 500 recent ticket messages are included. If Discord limits message content access, transcripts may have blanks. The log channel MUST be restricted to trusted staff. The ticket channel is deleted after closure and may not be recoverable.
- **Scalability:** Designed for one running bot process with SQLite and one persistent local database. For high-volume, multi-process or multi-host deployments, replace SQLite with a shared transactional database and review rate limits, monitoring and backup strategy.
- **Limitations:** This is not a hosted/SaaS bot, not a real payment system, has no external web dashboard, and does not include moderation of abusive message content. Keep `.env` private, restrict Discord administrator permissions, and obtain permission before storing others' credentials.

## Tests

With dependencies installed, run:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe -m compileall -q .
```

You can edit branding, embeds, colours and logging in the Python sources. `core.py` includes category-name validation, key generation and calendar-aware duration parsing; `storage.py` contains the schema and atomic claims; individual command groups are in the `cogs/` folder.


## Discriptive Welcome (RestoreCord edition)

Read `WELCOME_SETUP.md`. Verification is left to your independently installed RestoreCord bot; this bot has **no verify button or /verify commands**. The welcome image, @mention, template selection and settings remain.
