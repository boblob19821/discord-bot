@echo off
setlocal
cd /d "%~dp0"
title YZVT Bot - First Time Setup

echo.
echo ==========================================
echo        YZVT GENERATOR - SETUP
echo ==========================================
echo.
echo This installs Python packages into a private folder.
echo It does not delete existing stock or settings.
echo.

set "PYTHON_CMD="
py -3.12 -c "import sys" >nul 2>&1
if not errorlevel 1 set "PYTHON_CMD=py -3.12"
if not defined PYTHON_CMD (
  py -3.11 -c "import sys" >nul 2>&1
  if not errorlevel 1 set "PYTHON_CMD=py -3.11"
)
if not defined PYTHON_CMD (
  py -3.13 -c "import sys" >nul 2>&1
  if not errorlevel 1 set "PYTHON_CMD=py -3.13"
)
if not defined PYTHON_CMD (
  echo ERROR: A compatible Python version was not found.
  echo Install Python 3.12 from https://www.python.org/downloads/
  echo During installation, enable the Python launcher and Add Python to PATH.
  echo You can list detected versions with: py -0p
  goto :fail
)

echo Using %PYTHON_CMD%
echo.
if not exist ".venv\Scripts\python.exe" (
  echo [1/3] Creating Python virtual environment...
  %PYTHON_CMD% -m venv ".venv"
  if errorlevel 1 goto :fail
) else (
  echo [1/3] Virtual environment already exists.
)

echo [2/3] Installing all requirements...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :fail

echo [3/3] Preparing .env safely...
".venv\Scripts\python.exe" setup_config.py
if errorlevel 1 goto :fail

echo.
echo ==========================================
echo Setup completed.
echo ==========================================
echo Add your DISCORD_TOKEN to .env, and set TEST_GUILD_ID
 echo to your Discord server ID for quick slash commands.
echo To edit the settings, run: notepad .env
echo Then double-click start_windows.bat
 echo.
pause
exit /b 0

:fail
echo.
echo Setup could not finish. Copy the error shown above.
echo Do not share your bot token or encryption key.
pause
exit /b 1
