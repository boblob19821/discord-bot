"""Standalone Pillow welcome-card renderer. No Discord dependency.

Cards deliberately use common operating-system fonts. No fonts are bundled.
The function is synchronous; callers should run it in asyncio.to_thread.
"""
from __future__ import annotations

import io
import math
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, ImageOps

WIDTH, HEIGHT = 1050, 440

THEMES = {
    'midnight': {'base': (6, 11, 25), 'panel': (12, 22, 41), 'accent': '#27B7FF'},
    'royal': {'base': (13, 7, 30), 'panel': (25, 17, 54), 'accent': '#A17CFF'},
    'carbon': {'base': (12, 15, 19), 'panel': (22, 29, 35), 'accent': '#55E2C4'},
    'minimal': {'base': (16, 22, 34), 'panel': (23, 32, 45), 'accent': '#E8F0FF'},
}


def normalise_hex(value: str) -> str:
    value = value.strip().upper()
    if len(value) != 7 or not value.startswith('#') or any(c not in '0123456789ABCDEF' for c in value[1:]):
        raise ValueError('Use a hex colour such as #27B7FF.')
    return value


def colour_rgb(value: str):
    value = normalise_hex(value)
    return tuple(int(value[i:i + 2], 16) for i in (1, 3, 5))


def _font(size: int, bold: bool = False):
    names = ([
        'C:/Windows/Fonts/arialbd.ttf',
        '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
        '/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf',
    ] if bold else [
        'C:/Windows/Fonts/arial.ttf',
        '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
        '/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf',
    ])
    for path in names:
        if Path(path).exists():
            return ImageFont.truetype(path, size)
    return ImageFont.load_default()


def _truncate(draw, text: str, font, max_width: int):
    if draw.textlength(text, font=font) <= max_width:
        return text
    while len(text) > 1 and draw.textlength(text + '…', font=font) > max_width:
        text = text[:-1]
    return text + '…'


def render_card(*, username: str, server_name: str, member_count: int,
                avatar_bytes: bytes | None = None, brand: str = 'DISCRIPTIVE',
                theme: str = 'midnight', accent: str | None = None) -> bytes:
    """Generate a 1050x440 welcome graphic and return PNG bytes."""
    theme_config = THEMES.get(theme, THEMES['midnight'])
    accent_rgb = colour_rgb(accent or theme_config['accent'])
    bg = Image.new('RGB', (WIDTH, HEIGHT), theme_config['base'])
    pix = bg.load()
    base = theme_config['base']
    for y in range(HEIGHT):
        for x in range(WIDTH):
            light = (x / WIDTH) * 0.14 + (1 - y / HEIGHT) * 0.07
            # Soft atmosphere, no expensive gradients or external assets.
            dx, dy = x - 790, y - 60
            halo = max(0, 1 - math.hypot(dx, dy) / 720) * .18
            blend = min(.27, light + halo)
            pix[x, y] = tuple(int(c * (1 - blend) + a * blend) for c, a in zip(base, accent_rgb))
    draw = ImageDraw.Draw(bg)
    draw.rounded_rectangle((24, 24, WIDTH - 24, HEIGHT - 24), radius=28, fill=(*theme_config['panel'],))
    draw.rounded_rectangle((24, 24, WIDTH - 24, HEIGHT - 24), radius=28, outline=tuple(int(c * .45) for c in accent_rgb), width=2)
    draw.rectangle((24, 30, 32, HEIGHT - 30), fill=accent_rgb)
    # Simple geometric details are intentionally restrained for a clean brand look.
    for offset in (0, 48, 96):
        draw.line((840 + offset, 24, 1035 + offset, 225), fill=tuple(int(c * .24) for c in accent_rgb), width=2)
    draw.line((350, 346, 997, 346), fill=(46, 66, 86), width=2)

    cx, cy, radius = 207, 200, 107
    draw.ellipse((cx-radius-8, cy-radius-8, cx+radius+8, cy+radius+8), fill=accent_rgb)
    if avatar_bytes:
        try:
            avatar = Image.open(io.BytesIO(avatar_bytes)).convert('RGB')
            avatar = ImageOps.fit(avatar, (radius * 2, radius * 2), method=Image.Resampling.LANCZOS)
        except Exception:
            avatar = None
    else:
        avatar = None
    if avatar is not None:
        mask = Image.new('L', (radius * 2, radius * 2), 0)
        ImageDraw.Draw(mask).ellipse((0, 0, radius * 2-1, radius * 2-1), fill=255)
        bg.paste(avatar, (cx-radius, cy-radius), mask)
    else:
        draw.ellipse((cx-radius, cy-radius, cx+radius, cy+radius), fill=(26, 44, 69))
        letter = (username[:1] or '?').upper()
        f = _font(112, bold=True)
        bb = draw.textbbox((0,0), letter, font=f)
        draw.text((cx - (bb[2]-bb[0])/2, cy - (bb[3]-bb[1])/2 - bb[1]), letter, font=f, fill=(240,248,255))

    brand_font = _font(20, bold=True)
    title_font = _font(55, bold=True)
    name_font = _font(39, bold=True)
    body_font = _font(25)
    footer_font = _font(21)
    draw.text((353, 75), _truncate(draw, brand.upper(), brand_font, 595), font=brand_font, fill=accent_rgb)
    draw.text((350, 114), 'WELCOME', font=title_font, fill=(245, 249, 255))
    draw.text((353, 193), _truncate(draw, username, name_font, 625), font=name_font, fill=(255, 255, 255))
    draw.text((354, 265), _truncate(draw, f'TO {server_name}', body_font, 620), font=body_font, fill=(163, 180, 203))
    draw.text((353, 368), f'MEMBER #{member_count:,}', font=footer_font, fill=accent_rgb)
    draw.text((720, 368), 'SHOP  ·  GENERATE  ·  ENJOY', font=_font(16), fill=(157, 173, 194))
    output = io.BytesIO()
    bg.save(output, format='PNG', optimize=True)
    return output.getvalue()
